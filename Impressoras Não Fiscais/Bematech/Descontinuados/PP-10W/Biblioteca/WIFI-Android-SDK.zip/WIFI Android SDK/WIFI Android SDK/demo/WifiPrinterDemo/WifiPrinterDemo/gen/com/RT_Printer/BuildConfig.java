/** Automatically generated file. DO NOT MODIFY */
package com.RT_Printer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}