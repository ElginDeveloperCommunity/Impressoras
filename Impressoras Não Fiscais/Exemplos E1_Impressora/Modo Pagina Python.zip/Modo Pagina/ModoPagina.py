import impressora
import base64
from datetime import datetime
import ctypes


while True:
    print('\n*************************************************')
    print('**************** MENU IMPRESSORA *******************')
    print('*************************************************\n')


    print("1 - Abrir Conexao")
    print("2 - Impressao Texto")
    print("3 - Impressao Modo Pagina")
    print("4 - Modo Pagina Ext Reduzido")
    print("0 - Fechar Conexao")
    print("--------------------------------------")

    escolha = input ("\nDigite a opção desejada: ")

    if escolha == "0":
        while True:
            sair = input("Deseja sair (S / N): ").upper()
            if sair == "S":
                impressora.FechaConexaoImpressora()
                print("PRESSIONE ENTER PARA ENCERRAR")
                exit()
            elif sair == "N":
                break  # Sai do loop interno se a opção for "N"
            else:
                print("Opção inválida")
#____________________________________________________________________________
                
    elif escolha == "1":
        ret = impressora.AbreConexaoImpressora(1, "i9", "USB", 0)
        if ret == 0:
            print('\nConexão Aberta com sucesso')
        else:
            print('\nErro ao abrir conexao. Retorno: ', ret)
#____________________________________________________________________________
            
    elif escolha == "2":
        #txt = input("Digite o texto a ser impresso: ")
        ret = impressora.ImpressaoTexto("Teste de impressao", 1, 4, 0)
        impressora.Corte(5)

#____________________________________________________________________________  

    elif escolha == "3":

        retorno = impressora.ModoPagina()
        impressora.LimpaBufferModoPagina()
        impressora.InicializaImpressora()
        impressora.DefineAreaImpressao(0, 0, 580, 700)
        impressora.PosicaoImpressaoHorizontal(50)

        impressora.ImpressaoTexto("ELGIN AUTOMACAO", 1, 8, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("Rua das Olimpiadas, 205", 1, 0, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("Vila Olimpia - Sao Paulo", 1, 0, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("CNPJ: 14.200.166/0001-66", 1, 0, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("IE: 111.111111.1111", 1, 0, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("IM: 1.111.111/111-1", 1, 0, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("------------------------------------------------", 1, 8, 0)

        dataHoraAtual = datetime.now()
        dataHoraFormatada = dataHoraAtual.strftime("%d/%m/%Y %H:%M:%S")

        impressora.AvancaPapel(1)
        textoImpressao = f"{dataHoraFormatada}  CCF:000001   COO:000001"

        impressora.ImpressaoTexto(textoImpressao, 1, 0, 0)

        impressora.AvancaPapel(2)
        impressora.ImpressaoTexto("CUPOM FISCAL\n", 1, 8, 17)

        impressora.AvancaPapel(1)

        linhaCabecalho = "CODIGO   DESCRICAO            QTD    PUN   PRECO"
        impressora.ImpressaoTexto(linhaCabecalho, 0, 8, 0)

        impressora.ImpressaoTexto("001      Coca-Cola            2      4.99   9.98", 0, 8, 0)

        impressora.AvancaPapel(2)
        impressora.ImpressaoTexto("TOTAL:                                      9.98", 0, 8, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("Comete crime quem sonega", 0, 0, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("------------------------------------------------", 1, 8, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("OBSERVACOES DO CONTRIBUINTE", 0, 1, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("Trib aprox R$ 3,89 federal, R$ 5,16 estadual e R$ 0,00 municipal", 0, 1, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("CAIXA: 001  OPERADOR: Luiza", 0, 1, 0)

        impressora.AvancaPapel(2)
        impressora.ImpressaoTexto("*Valor aproximado dos tributos do item", 0, 1, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("Valor aproximado dos tributos deste cupom         R$ 1.37", 0, 1, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("Conforme lei Fed. 12.741/2012", 0, 1, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("------------------------------------------------", 1, 8, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("SAT NS. 900017840", 1, 8, 0)

        dataHoraAtual1 = datetime.now()
        dataHoraFormatada1 = dataHoraAtual1.strftime("%d/%m/%Y %H:%M:%S")

        impressora.AvancaPapel(1)
        textoImpressao1 = f"{dataHoraFormatada1}  CCF:000001   COO:000001"

        impressora.ImpressaoTexto(textoImpressao, 1, 8, 0)

        impressora.AvancaPapel(2)
        codigo = impressora.ImpressaoCodigoBarras(8, "{C35340133852246000140590006436230101542907111", 50, 2, 1)

        impressora.AvancaPapel(1)
        retorno1 = impressora.ImpressaoQRCode("Teste de QRCode para completar o XML do modo pagina", 5, 4)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("Atencao! Esse e um exemplo de cupom construido no modo pagina. E um cupom em base de homologacao...", 1, 0, 0)

        ret = impressora.ImprimeModoPagina()
        impressora.ModoPadrao()
        impressora.CorteTotal(5)

        if ret == 0:
            print("Impressão do modo Pagina realizada com sucesso!")

        else:
            print("Erro ao realizar a impressão!!! Retorno: ",ret)

#____________________________________________________________________________   
                
    elif escolha == "4":

        impressora.ImpressaoTexto("ELGIN AUTOMACAO", 1, 8, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("Rua das Olimpiadas, 205", 1, 0, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("Vila Olimpia - Sao Paulo", 1, 0, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("CNPJ: 14.200.166/0001-66", 1, 0, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("IE: 111.111111.1111", 1, 0, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("IM: 1.111.111/111-1", 1, 0, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("------------------------------------------------", 1, 8, 0)

        dataHoraAtual = datetime.now()
        dataHoraFormatada = dataHoraAtual.strftime("%d/%m/%Y %H:%M:%S")

        impressora.AvancaPapel(1)
        textoImpressao = f"{dataHoraFormatada}  CCF:000001   COO:000001"

        impressora.ImpressaoTexto(textoImpressao, 1, 0, 0)

        impressora.AvancaPapel(2)
        impressora.ImpressaoTexto("CUPOM FISCAL\n", 1, 0, 17)

        impressora.AvancaPapel(1)

        linhaCabecalho = "CODIGO   DESCRICAO            QTD    PUN   PRECO"
        impressora.ImpressaoTexto(linhaCabecalho, 0, 8, 0)

        impressora.ImpressaoTexto("001      Coca-Cola            2      4.99   9.98", 0, 8, 0)

        impressora.AvancaPapel(2)
        impressora.ImpressaoTexto("TOTAL:                                      9.98", 0, 8, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("Comete crime quem sonega", 0, 0, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("------------------------------------------------", 1, 8, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("OBSERVACOES DO CONTRIBUINTE", 0, 1, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("Trib aprox R$ 3,89 federal, R$ 5,16 estadual e R$ 0,00 municipal", 0, 1, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("CAIXA: 001  OPERADOR: Luiza", 0, 1, 0)

        impressora.AvancaPapel(2)
        impressora.ImpressaoTexto("*Valor aproximado dos tributos do item", 0, 1, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("Valor aproximado dos tributos deste cupom         R$ 1.37", 0, 1, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("Conforme lei Fed. 12.741/2012", 0, 1, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("------------------------------------------------", 1, 8, 0)

        impressora.AvancaPapel(1)
        impressora.ImpressaoTexto("SAT NS. 900017840", 1, 8, 0)

        dataHoraAtual1 = datetime.now()
        dataHoraFormatada1 = dataHoraAtual1.strftime("%d/%m/%Y %H:%M:%S")

        
        impressora.ModoPagina();
        # -------------------
        # --- Área QRCode ---
        # -------------------
        # Define Posições Texto do Produto
        impressora.DirecaoImpressao(0);
        impressora.DefineAreaImpressao(0, 0, 290, 700);
        impressora.PosicaoImpressaoHorizontal(0);
        impressora.PosicaoImpressaoVertical(0);
        impressora.ImpressaoQRCode('https://elgindevelopercommunity.github.io/group___m1.html#ga6dd4083b75e9221d85c780a9a35b5168', 5, 3);

        # ----------------
        # --- Área SAT ---
        # ----------------
        # Define Posições Texto do Produto
        impressora.DirecaoImpressao(0);
        impressora.DefineAreaImpressao(290, 0, 290, 700);
        impressora.PosicaoImpressaoHorizontal(0);
        impressora.PosicaoImpressaoVertical(0);

        # Define Textos
        impressora.ImpressaoTexto('SAT NS. 900020850', 1, 8, 0)
        impressora.AvancaPapel(1);
        
        dataHoraAtual1 = datetime.now()
        dataHoraFormatada1 = dataHoraAtual1.strftime("%d/%m/%Y %H:%M:%S")

        impressora.AvancaPapel(1)
        textoImpressao1 = f"{dataHoraFormatada1}"
        impressora.ImpressaoTexto(textoImpressao1, 1, 8, 0);
        impressora.AvancaPapel(1);
        
        impressora.ImpressaoTexto('4324 4324 4324 423432 4324 324', 1, 1, 0);
        impressora.AvancaPapel(2);
        impressora.ImpressaoTexto('Consulte o QR Code pelo aplicativo "de olho na nota", disponível na AppStore (Apple) e PlayStore (Android)', 1, 1, 0);

        impressora.ImprimeModoPagina()        
        impressora.Corte(2)
        
    
    else:
        print("OPÇÃO INVÁLIDA")
