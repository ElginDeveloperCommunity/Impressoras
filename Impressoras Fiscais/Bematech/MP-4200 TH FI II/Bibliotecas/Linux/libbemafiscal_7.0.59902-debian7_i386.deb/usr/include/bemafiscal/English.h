///////////////////////////////////////////////////////////
//  English.h
//  Implementation of the Class English
//  Created on:      17-mai-2011 14:41:27
//  Original author: adroaldo.filho
///////////////////////////////////////////////////////////

#if !defined(EA_E9E1BECE_57FB_4840_AC09_1091E2607F71__INCLUDED_)
#define EA_E9E1BECE_57FB_4840_AC09_1091E2607F71__INCLUDED_

#ifdef WIN32
	#ifndef __cplusplus
	#define DllExport __declspec(dllexport)
	#else
	#define DllExport extern "C" __declspec(dllexport)
	#endif
#else
	#define __stdcall
#endif

#if __cplusplus
	extern "C"
	{
#endif

//REGION_FISCAL_INFORMATION
int __stdcall Bematech_FI_Increments(char *incrementValue);
int __stdcall Bematech_FI_IncrementsICMS(char *incrementValue);
int __stdcall Bematech_FI_IncrementsISS(char *incrementValue);
int __stdcall Bematech_FI_Cancellations(char *cancellationValue);
int __stdcall Bematech_FI_CancellationsICMS(char *cancellationValue);
int __stdcall Bematech_FI_CancellationsISS(char *cancellationValue);
int __stdcall Bematech_FI_CGC_IE(char *CGC, char *IE);
int __stdcall Bematech_FI_CNPJMFD(char *CNPJ);
int __stdcall Bematech_FI_CNPJCV0909(char *CNPJ);
int __stdcall Bematech_FI_OwnerCliche(char *cliche);
int __stdcall Bematech_FI_NonFiscalVoucherNotIssuedMFD(char *voucher);
int __stdcall Bematech_FI_NonFiscalVoucherNotIssued(char *voucher);
int __stdcall Bematech_FI_CreditVouchersCounterMFD(char *voucher);
int __stdcall Bematech_FI_CreditVouchersCounter(char *voucher);
int __stdcall Bematech_FI_FiscalCouponCounterMFD(char *counter);
int __stdcall Bematech_FI_FiscalCouponCounter(char *counter);
int __stdcall Bematech_FI_NonFiscalTotalizerCounter(char *counter);
int __stdcall Bematech_FI_NonFiscalTotalizerCounterMFD(char *counter);
int __stdcall Bematech_FI_DetailTapeCounterMFD(char *counter);
int __stdcall Bematech_FI_DetailTapeCounter(char *counter);
int __stdcall Bematech_FI_CanceledNonFiscalOperationCounterMFD(char *counter);
int __stdcall Bematech_FI_CanceledNonFiscalOperationCounter(char *counter);
int __stdcall Bematech_FI_ManagementReportCounterMFD(char *counter);
int __stdcall Bematech_FI_ManagementReportCounter(char *counter);
int __stdcall Bematech_FI_DataLastReduction(char *dataReduction);
int __stdcall Bematech_FI_DataLastReductionMFD(char *dataReduction);
int __stdcall Bematech_FI_DataLastReductionCV0909(char *dataReduction);
int __stdcall Bematech_FI_AdditionalMFBasicSWUserDateTimeRecord(char *userDate, char *sbDate, char *additionalLetter);
int __stdcall Bematech_FI_DateHourPrinter(char *date, char *hour);
int __stdcall Bematech_FI_DateHourReduction(char *date, char *hour);
int __stdcall Bematech_FI_DateHourLastDocumentMFD(char *dateHour);
int __stdcall Bematech_FI_DateMove(char *date);
int __stdcall Bematech_FI_DateMoveLastReductionMFD(char *date);
int __stdcall Bematech_FI_Discounts(char *discountValue);
int __stdcall Bematech_FI_DiscountsICMS(char *discountValue);
int __stdcall Bematech_FI_DiscountsISS(char *discountValue);
int __stdcall Bematech_FI_FiscalFlags(short int *flag);
int __stdcall Bematech_FI_FiscalFlagsStr(char *flag);
int __stdcall Bematech_FI_FiscalFlags3MFD(short int *flag);
int __stdcall Bematech_FI_FlagsLinkISS(int *flag1, int *flag2);
int __stdcall Bematech_FI_TotalGrid(char *totalGrid);
int __stdcall Bematech_FI_TotalGridLastReductionMFD(char *totalGrid);
int __stdcall Bematech_FI_BeginEndCOOsMFD(char *COOBegin, char *COOEnd);
int __stdcall Bematech_FI_BeginEndTGsMFD(char *tgBegin, char *tgEnd);
int __stdcall Bematech_FI_StateRegistrationMFD(char *IE);
int __stdcall Bematech_FI_StateRegistration(char *IE);
int __stdcall Bematech_FI_MunicipalRegistrationMFD(char *IM);
int __stdcall Bematech_FI_MunicipalRegistration(char *IM);
int __stdcall Bematech_FI_PrinterTypeBrandModelMFD(char *brand, char *model, char *type);
int __stdcall Bematech_FI_MinutesSendingFiscalDocumentsMFD(char *minutes);
int __stdcall Bematech_FI_MinutesSendingFiscalDocumentsCV0909(char *minutes);
int __stdcall Bematech_FI_MinutesPrinting(char *minutes);
int __stdcall Bematech_FI_MinutesOn(char *minutes);
int __stdcall Bematech_FI_PrinterModel(char *model);
int __stdcall Bematech_FI_PrinterBrand(char *brand);
int __stdcall Bematech_FI_PrinterType(char *type);
int __stdcall Bematech_FI_PrinterModelVersion(char *cmModel, char *version);
int __stdcall Bematech_FI_PaperMonitor(int *lines);
int __stdcall Bematech_FI_CashDrawerNumber(char *number);
int __stdcall Bematech_FI_CouponNumber(char *couponNumber);
int __stdcall Bematech_FI_CouponNumberCV0909(char *couponNumber);
int __stdcall Bematech_FI_CanceledCouponNumber(char *couponNumber);
int __stdcall Bematech_FI_InterventionsNumber(char *number);
int __stdcall Bematech_FI_StoreNumber(char *storeNumber);
int __stdcall Bematech_FI_NonFiscalOperationsNumber(char *operationsNumber);
int __stdcall Bematech_FI_NonFiscalOperationsNumberCV0909(char *operationNumber);
int __stdcall Bematech_FI_ReductionsNumber(char *reductionsNumber);
int __stdcall Bematech_FI_SerialNumber(char *serialNumber);
int __stdcall Bematech_FI_CryptoSerialNumber(char *scryptoSerialNumber);
int __stdcall Bematech_FI_DecryptSerialNumber(char *cryptoSerialNumber, char *decryptSerialNumber);
int __stdcall Bematech_FI_MemorySerialNumberMFD(char *serialNumber);
int __stdcall Bematech_FI_SerialNumberMFD(char *serialNumberValue);
int __stdcall Bematech_FI_SerialNumberCV0909(char *serialNumber);
int __stdcall Bematech_FI_OwnerSubstitutionsNumber(char *substitutionsNumber);
int __stdcall Bematech_FI_FreePercentageMFD(char *freePercentage);
int __stdcall Bematech_FI_RemainingReductionsMFD(char *reductions);
int __stdcall Bematech_FI_RemainingReductions(char *reductions);
int __stdcall Bematech_FI_ReturnTaxes(char *taxes);
int __stdcall Bematech_FI_ReturnTaxesCV0909(char *taxes);
int __stdcall Bematech_FI_PrinterResponse(short int *ACK, short int *ST1, short int *ST2);
int __stdcall Bematech_FI_PrinterResponseMFD(short int *ACK, short int *ST1, short int *ST2, short int *ST3);
int __stdcall Bematech_FI_PrinterResponseCV0909(short int *CAT, short int *RET1, short int *RET2, short int *RET3, short int *RET4);
int __stdcall Bematech_FI_CurrencySymbol(char *currencySymbol);
int __stdcall Bematech_FI_ExtendedStatusMFD(short int *status);
int __stdcall Bematech_FI_SubTotal(char *subTotal);
int __stdcall Bematech_FI_SubTotalNonFiscalVoucherMFD(char *subTotal);
int __stdcall Bematech_FI_TotalSizeMFD(char *size);
int __stdcall Bematech_FI_UpTimeMFD(char *upTime);
int __stdcall Bematech_FI_UpTime(char *upTime);
int __stdcall Bematech_FI_RemainingTimeVoucherMFD(char *remainingTime);
int __stdcall Bematech_FI_CouponTotalICMS(char *ICMS);
int __stdcall Bematech_FI_CouponTotalISSMFD(char *ISS);
int __stdcall Bematech_FI_TotalFreeMFD(char *size);
int __stdcall Bematech_FI_OwnerUFMFD(char *UF);
int __stdcall Bematech_FI_OwnerUF(char *UF);
int __stdcall Bematech_FI_LastSoldItem(char *itemNumber);
int __stdcall Bematech_FI_ValuePaymentForm(char *form, char *value);
int __stdcall Bematech_FI_ValuePaymentFormMFD(char *form, char *value);
int __stdcall Bematech_FI_PayedValueLastCoupon(char *value);
int __stdcall Bematech_FI_GrossSales(char *grossSales);
int __stdcall Bematech_FI_ValueNonFiscalTotalizer(char *totalizer, char *valueTotalizer);
int __stdcall Bematech_FI_ValueNonFiscalTotalizerMFD(char *totalizer, char *valueTotalizer);
int __stdcall Bematech_FI_VerifyIssTaxes(char *flags);
int __stdcall Bematech_FI_VerifyCancel2HoursCouponMFD(char *flag);
int __stdcall Bematech_FI_VerifyCommandSpecificationVersion(char *ecfNumber);
int __stdcall Bematech_FI_VerifyDepartments(char *departments);
int __stdcall Bematech_FI_VerifyEpromConnected(char *flag);
int __stdcall Bematech_FI_VerifyCashDrawerState(short int *flag);
int __stdcall Bematech_FI_VerifyPrinterState(short int *ACK, short int *ST1, short int *ST2);
int __stdcall Bematech_FI_VerifyPrinterStateMFD(short int *ACK, short int *ST1, short int *ST2, short int *ST3);
int __stdcall Bematech_FI_VerifyCutFlagMFD(short int *flag);
int __stdcall Bematech_FI_VerifyPaymentForm(char *form);
int __stdcall Bematech_FI_VerifyPaymentFormMFD(char *form);
int __stdcall Bematech_FI_VerifyPaymentFormCV0909(char *form);
int __stdcall Bematech_FI_VerifyPrinterOn();
int __stdcall Bematech_FI_VerifyISSTaxIndex(char *index);
int __stdcall Bematech_FI_VerifyISSTaxIndexCV0909(char *index);
int __stdcall Bematech_FI_VerifyOperationMode(char *mode);
int __stdcall Bematech_FI_VerifyOperationModeCV0909(char *mode);
int __stdcall Bematech_FI_VerifyPrinterMode(char *mode);
int __stdcall Bematech_FI_VerifyGreetingNonFiscal(char *greetingsValue);
int __stdcall Bematech_FI_VerifyGreetingNonFiscalMFD(char *greetingsValue);
int __stdcall Bematech_FI_VerifyGreetingNonFiscalCV0909(char *greetingsValue);
int __stdcall Bematech_FI_VerifyAutomaticallyZReduction(short int *flag);
int __stdcall Bematech_FI_VerifyManagementReportMFD(char *reports);
int __stdcall Bematech_FI_VerifyManagementReport(char *reports);
int __stdcall Bematech_FI_VerifyLowPaperSensorMFD(char *flag);
int __stdcall Bematech_FI_VerifyPaymentCheckStatus(short int *status);
int __stdcall Bematech_FI_VerifyPrinterType(short int *printerType);
int __stdcall Bematech_FI_VerifyTotalizersNonFiscal(char *totalizers);
int __stdcall Bematech_FI_VerifyTotalizersNonFiscalIO(char *totalizers);
int __stdcall Bematech_FI_VerifyTotalizersNonFiscalMFD(char *totalizers);
int __stdcall Bematech_FI_VerifyTotalizersNonFiscalCV0909(char *totalizers);
int __stdcall Bematech_FI_VerifyPartialTotalizers(char *totalizers);
int __stdcall Bematech_FI_VerifyPartialTotalizersMFD(char *totalizers);
int __stdcall Bematech_FI_VerifyTruncation(char *flag);
int __stdcall Bematech_FI_SoVersion(char *version);
int __stdcall Bematech_FI_FirmwareVersion(char *version);
int __stdcall Bematech_FI_FirmwareVersionMFD(char *version);
int __stdcall Bematech_FI_FirmwareVersionCV0909(char *version);
int __stdcall Bematech_FI_PrepareOpenCoupon(char *coupon, char *couponCounter, short int *flag, char *date, char *hour, char *serialNumber, char *totalGrid);
int __stdcall Bematech_FI_NetSales(char *netSales);
int __stdcall Bematech_FI_NumberDecimalsUnitaryValue(char *decimals);
int __stdcall Bematech_FI_NumberDecimalsQuantity(char *decimals);
int __stdcall Bematech_FI_EscECFVersion(char *version);
int __stdcall Bematech_FI_AcronymMunicipality(char *acronym);
int __stdcall Bematech_FI_ReturnPublicKeys(char *basicSoftwarePublicKey, char *eletronicFilesPublicKey, char *issuedFilesPublicKey, char *remoteAccessKey, char *MIL_MITPublicKey);
int __stdcall Bematech_FI_ICMSISSTotalizers(char *totalizers);
int __stdcall Bematech_FI_FINTotalizers(char *totalizers);
int __stdcall Bematech_FI_ManagementReportTable(char *reports);
int __stdcall Bematech_FI_PaymentFormsTable(char *forms);
int __stdcall Bematech_FI_VerifyPaperStatus(char *status);
int __stdcall Bematech_FI_AmountRemainingCoupons(char *amount);
int __stdcall Bematech_FI_VerifyURLDataTransmission(char *url);
int __stdcall Bematech_FI_TimeSendingOperationalCV0909(char *minutes, char *uptime);
int __stdcall Bematech_FI_StatusCurrentFiscalDay(char *movementDate, int status, char *initialCOO, char *initialTotalGrid);
int __stdcall Bematech_FI_TotalGridCryptography(char *criptoTotalGrid);
int __stdcall Bematech_FI_VerifyPaperStatus(char *status);
int __stdcall Bematech_FI_VerifyCoverStatus(char *status);
int __stdcall Bematech_FI_VerifyPendingZ(char *status);
int __stdcall Bematech_FI_VerifyPrinterContext(char *status);
int __stdcall Bematech_FI_BufferResponseCV0909(char *buffer);
int __stdcall Bematech_FI_TradeName(char *name);
int __stdcall Bematech_FI_CompanyName(char *name);
int __stdcall Bematech_FI_CompanyAddress(char *address);
int __stdcall Bematech_FI_ProgramedHeaderAlignment(char *programedHeaderAlignment);
int __stdcall Bematech_FI_ProgramedRTDTimeout(char *programedRTDTimeout);
int __stdcall Bematech_FI_ProgramedPrinterPriority(char *programedPrinterPriority);
int __stdcall Bematech_FI_ProgramedPaperReturn(char *programedPaperReturn);


//REGION_FISCAL_PRINTER
int __stdcall Bematech_FI_OpeningDay(char *valueAux, char *paymentForm);
int __stdcall Bematech_FI_OpenNonFiscalLinkedVoucher(char *paymentForm, char *value, char *couponNumber);
int __stdcall Bematech_FI_OpenNonFiscalLinkedVoucherMFD(char *paymentForm, char *value, char *couponNumber, char *CPF, char *name, char *address);
int __stdcall Bematech_FI_OpenNonFiscalLinkedVoucherCV0909(int paymentSequence, char *paymentFormIndex, int quantityOfPayments, int paymentNumber, char *CPF, char *name, char *address);
int __stdcall Bematech_FI_OpenCoupon(char *CPF);
int __stdcall Bematech_FI_OpenCouponMFD(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_OpenCouponCV0909(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_OpenNonFiscalReceivingMFD(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_OpenNonFiscalReceivingCV0909(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_OpenManagementReportMFD(char *totalizer);
int __stdcall Bematech_FI_OpenManagementReportCV0909(char *totalizer);
int __stdcall Bematech_FI_OpenNonFiscalLinkedCopyMFD();
int __stdcall Bematech_FI_ActiveCashDrawer();
int __stdcall Bematech_FI_ActivePaperCutterMFD(short int mode);
int __stdcall Bematech_FI_ActivePaperCutterCV0909();
int __stdcall Bematech_FI_IncrementDiscountItemMFD(char *item, char *incrementDiscount, char *incrementDiscountType, char *incrementDiscountValue);
int __stdcall Bematech_FI_IncrementDiscountItemCV0909(char *item, char *incrementDiscount, char *incrementDiscountType, char *incrementDiscountValue);
int __stdcall Bematech_FI_IncrementDiscountSubTotalMFD(char *flag, char *type, char *value);
int __stdcall Bematech_FI_IncrementDiscountSubTotalCV0909(char *flag, char *type, char *value);
int __stdcall Bematech_FI_IncrementDiscountReceivingSubTotalMFD(char *flag, char *type, char *value);
int __stdcall Bematech_FI_IncrementDiscountNonFiscalItemMFD(char *item, char *incrementDiscount, char *incrementDiscountType, char *incrementDiscountValue);
int __stdcall Bematech_FI_ChangeCurrencySymbol(char *currencySymbol);
int __stdcall Bematech_FI_IncreasesItemDescription(char *description);
int __stdcall Bematech_FI_Authentication();
int __stdcall Bematech_FI_AuthenticationMFD(char *lines, char *text);
int __stdcall Bematech_FI_CancelIncrementDiscountItemMFD(char *flag, char *item);
int __stdcall Bematech_FI_CancelIncrementDiscountItemCV0909(char *flag, char *item);
int __stdcall Bematech_FI_CancelIncrementDiscountSubTotalMFD(char *flag);
int __stdcall Bematech_FI_CancelIncrementDiscountSubTotalCV0909(char *flag);
int __stdcall Bematech_FI_CancelIncrementDiscountReceivingSubTotalMFD(char *flag);
int __stdcall Bematech_FI_CancelIncrementNonFiscalMFD(char *item, char *incrementDiscount);
int __stdcall Bematech_FI_CancelCoupon();
int __stdcall Bematech_FI_CancelCouponMFD(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_CancelCouponCV0909(char *COO);
int __stdcall Bematech_FI_CancelCouponInIssueCV0909();
int __stdcall Bematech_FI_CancelPaymentCheckPrinting();
int __stdcall Bematech_FI_CancelItemPartially(char *item, char *quantity);
int __stdcall Bematech_FI_CancelPreviousItem();
int __stdcall Bematech_FI_CancelGenericItem(char *item);
int __stdcall Bematech_FI_CancelNonFiscalItemMFD(char *item);
int __stdcall Bematech_FI_CancelNonFiscalItem(char *item);
int __stdcall Bematech_FI_CancelNonFiscalReceivingsMFD(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_AdditionalCouponMFD();
int __stdcall Bematech_FI_MFDownload(char *fileName);
int __stdcall Bematech_FI_MFDownloadCV0909(char *fileName, char *type, char *initialData, char *finalData);
int __stdcall Bematech_FI_MFDDownload(char *fileName, char *downloadType, char *initialData, char *finalData, char *user);
int __stdcall Bematech_FI_MFDDownloadCV0909(char *fileName, char *downloadType, char *initialData, char *finalData);
int __stdcall Bematech_FI_SBDownload(char *fileName);
int __stdcall Bematech_FI_SBDownloadCV0909(char *fileName);
int __stdcall Bematech_FI_TDMDownload(char *fileName, char *type, char *initialData, char *finalData);
int __stdcall Bematech_FI_MakesPaymentForm(char *paymentForm, char *value);
int __stdcall Bematech_FI_MakesDescriptionPaymentForm(char *paymentForm, char *value, char *description);
int __stdcall Bematech_FI_MakesPaymentFormIndex(char *paymentFormIndex, char *value);
int __stdcall Bematech_FI_MakesDescriptionPaymentFormIndex(char *paymentFormIndex, char *value, char *description);
int __stdcall Bematech_FI_MakesPaymentFormMFD(char *paymentForm, char *value, char *payments, char *description);
int __stdcall Bematech_FI_MakesPaymentFormIndexMFD(char *paymentFormIndex, char *value, char *payments, char *description);
int __stdcall Bematech_FI_MakesPaymentFormIndexCV0909(char *paymentFormIndex, char *value, char *payments, char *description, char *paymentFormCode);
int __stdcall Bematech_FI_MakesNonFiscalPaymentMFD(char *totalizerIndex, char *value);
int __stdcall Bematech_FI_MakesNonFiscalPaymentCV0909(char *totalizerIndex, char *value);
int __stdcall Bematech_FI_CancelPaymentForms(char *originForm, char *destinyForm, char *value);
int __stdcall Bematech_FI_CancelPaymentFormsCV0909(char *originForm, char *destinyForm, char *value, int destinyPaymentSequence, char *message);
int __stdcall Bematech_FI_CancelNonFiscalLinkedMFD(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_CancelNonFiscalLinkedCV0909(char *CPF, char *name, char *address, char *COO);
int __stdcall Bematech_FI_CancelNonFiscalLinkedLaterMFD(char *paymentForm, char *value, char *couponCOO, char *CDCCOO, char *CPF, char *name, char *address);
int __stdcall Bematech_FI_CloseNonFiscalLinkedVoucher();
int __stdcall Bematech_FI_CloseCoupon(char *paymentForm, char *incrementsDiscount, char *incrementsDiscountType, char *incrementsDiscountValue, char *payedValue, char *message);
int __stdcall Bematech_FI_CloseShortCoupon(char *paymentForm, char *message);
int __stdcall Bematech_FI_CloseNonFiscalReceivingMFD(char *message);
int __stdcall Bematech_FI_CloseNonFiscalReceivingCV0909(char *message, int cutter);
int __stdcall Bematech_FI_CloseManagementReport();
int __stdcall Bematech_FI_CloseManagementReportCV0909(int cutter);
int __stdcall Bematech_FI_CloseDay();
int __stdcall Bematech_FI_DataMFDFormat(char *MFDFile, char *destiny, char *format, char *downloadType, char *initialData, char *finalData, char *user);
int __stdcall Bematech_FI_DataMFFormat(char *MFDFile, char *destiny, char *format, char *readType, char *parameterType, char *initialData, char *finalData);
int __stdcall Bematech_FI_DetailTapePrint(char *type, char *initialData, char *finalData, char *user);
int __stdcall Bematech_FI_DetailTapePrintCV0909(char *type, char *initialData, char *finalData);
int __stdcall Bematech_FI_PrintClicheMFD();
int __stdcall Bematech_FI_PrintPrinterConfigurations();
int __stdcall Bematech_FI_PrintDepartments();
int __stdcall Bematech_FI_StartsClosingCoupon(char *incrementDiscount, char *incrementDiscountType, char *incrementDiscountValue);
int __stdcall Bematech_FI_StartsClosingCouponMFD(char *incrementDiscount, char *incrementDiscountType, char *incrementValue, char *discountValue);
int __stdcall Bematech_FI_StartsClosingNonFiscalReceivingMFD(char *incrementDiscount, char *incrementDiscountType, char *incrementValue, char *discountValue);
int __stdcall Bematech_FI_FiscalMemoryReadByDate(char *initialDate, char *finalDate);
int __stdcall Bematech_FI_FiscalMemoryReadByDateMFD(char *initialDate, char *finalDate, char *readFlag);
int __stdcall Bematech_FI_FiscalMemoryReadByDateCV0909(char *initialDate, char *finalDate, char *readFlag);
int __stdcall Bematech_FI_FiscalMemoryReadByReduction(char *initialReduction, char *finalReduction);
int __stdcall Bematech_FI_FiscalMemoryReadByReductionMFD(char *initialReduction, char *finalReduction, char *readFlag);
int __stdcall Bematech_FI_FiscalMemoryReadByReductionCV0909(char *initialReduction, char *finalReduction, char *readFlag);
int __stdcall Bematech_FI_FiscalSerialMemoryReadByDate(char *initialDate, char *finalDate);
int __stdcall Bematech_FI_FiscalSerialMemoryReadByDateMFD(char *initialDate, char *finalDate, char *readFlag);
int __stdcall Bematech_FI_FiscalSerialMemoryReadByDateCV0909(char *initialDate, char *finalDate, char *readFlag);
int __stdcall Bematech_FI_FiscalSerialMemoryReadByReduction(char *initialReduction, char *finalReduction);
int __stdcall Bematech_FI_FiscalSerialMemoryReadByReductionMFD(char *initialReduction, char *finalReduction, char *readFlag);
int __stdcall Bematech_FI_FiscalSerialMemoryReadByReductionCV0909(char *initialReduction, char *finalReduction, char *readFlag);
int __stdcall Bematech_FI_XRead(void);
int __stdcall Bematech_FI_SerialXRead(void);
int __stdcall Bematech_FI_SummaryMap(void);
int __stdcall Bematech_FI_SummaryMapMFD(void);
int __stdcall Bematech_FI_NonFiscalReceiving(char *totalizerIndex, char *receivingValue, char *paymentForm);
int __stdcall Bematech_FI_ZReduction(char *date, char *hour);
int __stdcall Bematech_FI_ZReductionCV0909(char *date, char *hour, int transmit);
int __stdcall Bematech_FI_ReprintNonFiscalLinkedMFD();
int __stdcall Bematech_FI_ReprintNonFiscalLinkedCV0909();
int __stdcall Bematech_FI_ManagementReport(char *text);
int __stdcall Bematech_FI_PrinterReset();
int __stdcall Bematech_FI_Withdraw(char *value);
int __stdcall Bematech_FI_WithdrawCV0909(char *value, char *message);
int __stdcall Bematech_FI_NonFiscalLinkedCopyMFD();
int __stdcall Bematech_FI_NonFiscalLinkedCopyCV0909();
int __stdcall Bematech_FI_MakesSubtotalCouponMFD();
int __stdcall Bematech_FI_MakesReceivingSubtotalMFD();
int __stdcall Bematech_FI_Supply(char *value, char *paymentForm);
int __stdcall Bematech_FI_SupplyCV0909(char *value, char *message);
int __stdcall Bematech_FI_SetMFD(int flagMFD);
int __stdcall Bematech_FI_FinishPaymentCoupon(char *message);
int __stdcall Bematech_FI_FinishPaymentCouponCV0909(char *message, int additionalCoupon, int cutter);
int __stdcall Bematech_FI_FinishPaymentCouponBarCodeMFD(const char *tmpMessage, const char *codeType, const char *code, int height, int tmpWidth, int characterPosition, int source, int margin, int fixErrors, int columns);
int __stdcall Bematech_FI_TotalizeReceivingMFD();
int __stdcall Bematech_FI_UseNonFiscalLinkedVoucher(char *text);
int __stdcall Bematech_FI_UseManagementReportMFD(char *text);
int __stdcall Bematech_FI_UseManagementReportCV0909(char *text);
int __stdcall Bematech_FI_SellItem(char *code, char *description, char *tax, char *quantityType, char *quantity, short int decimal, char *unitary, char *discountType, char *discount);
int __stdcall Bematech_FI_SellItemCV0909(char *code, char *description, char *tax, char *quantity, short decimal, char *unitaryValue, char *unitOfMeasure, char *decimalsUnitaryValue, char *typeOfCalculation);
int __stdcall Bematech_FI_SellItemDetailedCV0909(char *code,char *description,char *tax,char *unitOfMeasure,char *quantity,char *decimalsQuantity,char *unitaryValue, char *decimalUnitaryValue, char *typeOfCalculation, char *EAN13, char *NCM, char *CFOP, char *additionalInformation, char *productOrigin, char *CST_ICMS, char *simplesCode, char *IBGECityCode, char * itemServiceList, char *ISSCode, char *ISSOperationNature, char *ISSIncentiveIndicator);
int __stdcall Bematech_FI_SellItemComplete(char *code, char *EAN13, char *description, char *indexDepartment, char *tax, char *unitOfMeasure, char *quantityType, char *decimalsQuantity, char *quantity, char *decimalsUnitaryValue, char *unitaryValue, char *increaseDiscountType, char *incrementValue, char *discountValue, char *typeOfCalculation, char *NCM, char *CFOP, char *additionalInformation, char *CST_ICMS, char *productOrigin, char *itemServiceList, char *ISSCode, char *ISSOperationNature, char *ISSIncentiveIndicator, char *IBGECode, char *CSOSN, char *basisCalculuationValueRetained, char *ICMSValueRetained, char *basisCalculationMode, char *basisCalculationReductionPercentual, char *ICMSSTBasisCalculationMode, char *ICMSSTValueAddedMarginPercentual, char *ICMSSTBasisCalculationReductionPercentual, char *ICMSSTBasisCalculationReductionValue, char *ICMSSTTax, char *ICMSSTValue, char *ICMSUnencumberedValue, char *ICMSUnburdeningMotive, char *creditCalculationApplicableTax, char *ICMSSNCreditValue, char *incidentTaxTotalValue, char *pisCst, char *pisBasisCalculation, char *pisTax, char *pisValue, char *pisQuantitySell, char *pisTaxValueProd, char *cofinsCst, char *cofinsBasisCalculation, char *cofinsTax, char *cofinsValue, char *cofinsQuantitySell, char *cofinsTaxValueProd, char *reserved01, char *reserved02, char *reserved03, char *reserved04, char *reserved05, char *reserved06, char *reserved07, char *reserved08, char *reserved09, char *reserved10);
int __stdcall Bematech_FI_SellRoudingItemMFD(char *code, char *description, char *tax, char *unitOfMeasure, char *quantityFractionated, char *unitary, char *incrementValue, char *discountValue, bool rounds);
int __stdcall Bematech_FI_SellDepartmentItem(char *code, char *description, char *tax, char *unitValue, char *quantity, char *incrementValue, char *discountValue, char *indexDepartment, char *unitOfMeasure);
int __stdcall Bematech_FI_TotalizeCouponMFD();
int __stdcall Bematech_FI_UsesUnitOfMeasure(char *unitOfMeasure);
int __stdcall Bematech_FI_ReturnFatMFD(void);

//NFCe
int __stdcall Bematech_FI_FinishPaymentCouponNFCe(char *message, char *taxes);
int __stdcall Bematech_FI_ConsumerDataNFCe(char *CPF, char *name, char *address, char *complement, char *number, char *neighborhood, char *IBGECode, char *city, char *UF, char *CEP, char *countyCode, char *country, char *phone, char *stateRegistrationIndicator,char *stateRegistration, char *SUFRAMACode, char *email);
int __stdcall Bematech_FI_AccessKeyNFCe(char *index, char *counter, char *accessKey);
int __stdcall Bematech_FI_LastAccessKeyNFCe(char *accessKey);
int __stdcall Bematech_FI_LastStatusNFCe(char *status);
int __stdcall Bematech_FI_GetInformationNFCe(char* type, char *value, char* accessKey, char* serie, 
											 char* NFCeNumber, char* cancelled, char* sendStatus, char* sendProtocol, 
											 char* sendProtocolDatetime, char* cancellationStatus, char* cancellationProtocol);
int __stdcall Bematech_FI_LastStatusCancNFCe(char *status);
int __stdcall Bematech_FI_ProgramCounterNFCe(char *index, char *counter);
int __stdcall Bematech_FI_SerialNumberNFCe(char *serialNumber);
int __stdcall Bematech_FI_NoteNumberNFCe(char *noteNumber);
int __stdcall Bematech_FI_ParametersNFCe(char *layoutType, char *sendType, char *email);
int __stdcall Bematech_FI_MakesPaymentFormNFCeEx(char *paymentForm, char *value, char *licensingCNPJ, char *licensingCode, char *authorizationCode, char *integrationCode);

//SAT
int __stdcall Bematech_FI_AddPISCOFINSSTSAT(char *itemIndex, char *pisSTBasisCalculation, char *pisSTTax, char *pisSTQuantitySell, char *pisSTTaxValueProd, char *cofinsSTBasisCalculationm, char *cofinsSTTax, char *cofinsSTQuantitySell, char *cofinsSTTaxValueProd);
int __stdcall Bematech_FI_LastInformationSAT(char *accessKey, char *billNumber, char *satNumber);
int __stdcall Bematech_FI_SefazMessageSAT(char *message, char *code, char *errorMessage, char *errorCode);
int __stdcall Bematech_FI_DeliveryDataSAT(char *address, char *number, char *complement, char *neighborhood, char *city, char *UF);
int __stdcall Bematech_FI_SoftwareHouseDataSAT(char *CNPJ, char *softwareSignature);
int __stdcall Bematech_FI_EnableDisableExtendedOutputSAT(char *extendedOutput);
int __stdcall Bematech_FI_InsertFiscoFreeUseFieldSAT(char *itemIndex, char *identification, char *content);
int __stdcall Bematech_FI_CancelationInformationSAT(char *cfeAccessKey, char *cancelationAccessKey, char *processedDateTime, char *sefazCode, char *sefazMessage);

int __stdcall Bematech_FI_PrintRTDCV0909(char *message);

//REGION_FISCAL_PROGRAMATION
int __stdcall Bematech_FI_ProgramsConsumerIdentification(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_ProgramsTaxAmount(char *taxAmount, int typeOfAmount);
int __stdcall Bematech_FI_ProgramsTaxAmountCV0909(char *taxAmount, int typeOfAmount, char *taxIndex);
int __stdcall Bematech_FI_ProgramsSpecialTaxAmountCV0909(char *taxF, char *taxI, char *taxN, char *taxFS, char *taxIS, char *taxNS);
int __stdcall Bematech_FI_ProgramsDaylightSavings(void);
int __stdcall Bematech_FI_ProgramsDaylightSavingsCV0909(int mode);
int __stdcall Bematech_FI_namesICMSExemptTotalizer(int index, char *totalizer);
int __stdcall Bematech_FI_namesICMSExemptTotalizerCV0909(int index, char *totalizer, char *inOrOut);
int __stdcall Bematech_FI_ProgramsRounding(void);
int __stdcall Bematech_FI_ProgramsTruncation(void);
int __stdcall Bematech_FI_NamesDepartment(int index, char *department);
int __stdcall Bematech_FI_LinesBetweenCoupon(int lines);
int __stdcall Bematech_FI_SpaceBetweenLines(int dots);
int __stdcall Bematech_FI_ProgramCurrencySingular(char *singularCurrency);
int __stdcall Bematech_FI_ProgramCurrencyPlural(char *pluralCurrency);
int __stdcall Bematech_FI_AppIdProgramMFD(char *idApp);
int __stdcall Bematech_FI_AppIdProgramCV0909(char *idApp);
int __stdcall Bematech_FI_PrintheadImpactForce(short int impactValue);
int __stdcall Bematech_FI_ProgramAuthenticateCharacter(char *parameters);
int __stdcall Bematech_FI_EnableDisableLeftAlignMFD(short int flag);
int __stdcall Bematech_FI_EnableDisable2HoursCouponMFD(int flag);
int __stdcall Bematech_FI_EnableDisableNextCutMFD(void);
int __stdcall Bematech_FI_EnableDisableTotalCutMFD(int flag);
int __stdcall Bematech_FI_EnableDisablePaperCutterMFD(short int flag);
int __stdcall Bematech_FI_EnableDisableSensorPaperLightMFD(int flag);
int __stdcall Bematech_FI_EnableDisableONOFFLineTreatmentMFD(short int flag);
int __stdcall Bematech_FI_EnableDisableOneLineSaleMFD(short int flag);
int __stdcall Bematech_FI_AdvancePaperTriggerPaperCutterMFD(short int lines, short int mode);
int __stdcall Bematech_FI_ConfigurePaperCutterMFD(int time);
int __stdcall Bematech_FI_NamesReportManagementMFD(char *index, char *description);
int __stdcall Bematech_FI_NamesReportManagementCV0909(char *index, char *description);
int __stdcall Bematech_FI_ProgramsPaymentFormMFD(char *paymentForm, char *operationTef);
int __stdcall Bematech_FI_ProgramsPaymentFormCV0909(char *paymentIndex, char *paymentForm, int linkedCCD);
int __stdcall Bematech_FI_InterruptReadCV0909(void);
int __stdcall Bematech_FI_ProgramsStore(char *storeNumber);
int __stdcall Bematech_FI_ProgramsLimitAutorizedDocuments(char *data);
int __stdcall Bematech_FI_ProgramsOperator(char *data);

//REGION_FISCAL_UTILS
void __stdcall Bematech_FI_EncryptsDecrypts(char *buffer, unsigned int sizeBuffer, char *key = "", unsigned int sizeKey = 0);
void __stdcall Bematech_FI_ReloadXMLFile();
void __stdcall Bematech_FI_ReloadINIFile();
int __stdcall Bematech_FI_SelectLocalXML();
int __stdcall Bematech_FI_SelectLocalIni();
int __stdcall Bematech_FI_EnableDisableExtendedReturnMFD(char *extendedFlag);

//REGION_CRYPTO
int __stdcall Bematech_FI_GenerateKey(char *publicKey, char *privateKey);
int __stdcall genkkey(char *publicKey, char *privateKey);
int __stdcall Bematech_FI_GenerateEAD(char *filename, char *publicKey, char *privateKey, char *eadSignature, int appendToFile);
int __stdcall generateEAD(char *filename, char *publicKey, char *privateKey, char *eadSignature, int appendToFile);
int __stdcall Bematech_FI_GetMD5FromFile(const char *filename, const char *md5, int signature);
int __stdcall md5FromFile(const char *filename, const char *md5);
int __stdcall setLibType(int type);
int __stdcall Bematech_FI_CheckEADSignature(char *filename, char *publicKey, char *privateKey);
int __stdcall Bematech_FI_CheckEADSignatureEECFC(char *filename, char *module, char *exponent);
int __stdcall validateFile(char *filename, char *publicKey, char *privateKey);

//REGION_PAF
int __stdcall Bematech_FI_OpenSaleAuxiliarDocument(char *index, char *title, char *DAVNumber, char *issuerName, char *issuerCNPJCPF, char *recipientName, char *recipientCNPJCPF);
int __stdcall Bematech_FI_OpenPaymentFormsReport(char *index);
int __stdcall Bematech_FI_MFDFile(char *fileName, char *initialData, char *finalData, char *downloadType, char *user, int parameter, char *publicKey, char *privateKey, int singleFile);
int __stdcall Bematech_FI_MFDFilePath(char *fileName,char * destinyFileName, char *initialData, char *finalData, char *downloadType, char *user, int parameter, char *publicKey, char *privateKey, int singleFile);
int __stdcall Bematech_FI_DAVIssuedFile(char *fileName, char *initialDate, char *finalDate, char *publicKey, char *privateKey);
int __stdcall Bematech_FI_DAVIssuedManagementReport(char *index, char *initialDate, char *finalDate);
int __stdcall Bematech_FI_MFDCopy(char *destinyFileName, char *initialData, char *finalData, char *downloadType, char *user, char *publicKey, char *privateKey);
int __stdcall Bematech_FI_CloseSaleAuxiliarDocument(char *total);
int __stdcall Bematech_FI_ClosePaymentFormsReport();
int __stdcall Bematech_FI_CryptoTotalGrid(char *totalGrid);
int __stdcall Bematech_FI_DecryptTotalGrid(char *encryptedTotalGrid, char *decryptTotalGrid);
int __stdcall Bematech_FI_PAFECFIdentification(char *index, char *reportNumber, char *developerCNPJ, char *companyName, char *address, char *phone, char *contact, char *tradeName, char *version, char *mainExecutable, char *mainExecutableMD5, char *otherFiles, char *otherFilesMD5, char *registrationNumber);
int __stdcall Bematech_FI_FiscalSerialMemoryReadByDatePAFECF(char *initialDate, char *finalDate, char *readFlag, char *publicKey, char *privateKey);
int __stdcall Bematech_FI_FiscalSerialMemoryReadByReductionPAFECF(char *initialReduction, char *finalReduction, char *readFlag, char *publicKey, char *privateKey);
int __stdcall Bematech_FI_NamesIssuedDAVReport();
int __stdcall Bematech_FI_NamesSaleAuxiliarDocumentReport();
int __stdcall Bematech_FI_NamesPAFECFIdentificationReport();
int __stdcall Bematech_FI_NamesPaymentFormReport();
int __stdcall Bematech_FI_NamesPAFECFReports();
int __stdcall Bematech_FI_FinishPaymentCouponPreSale(char *MD5, char *preSaleNumber, char *promotionalMessage);
int __stdcall Bematech_FI_UseSaleAuxiliarDocument(char *item, char *unitValue, char *totalValue);
int __stdcall Bematech_FI_UsePaymentFormsReport(char *identification, char *documentType, char *accumulatedValue, char *date);
int __stdcall Bematech_FI_NamesReports(char *name);

//REGION_CAT52
int __stdcall Bematech_FI_GenerateRegisterCAT52MFD(char *MFDFile, char *date);
int __stdcall Bematech_FI_GenerateRegisterCAT52MFDEx(char *source, char *date, char *destiny);
void __stdcall Bematech_FI_changeETypeParametrizationRegister(int parametrization);

//REGION_SPED
int __stdcall Bematech_FI_GenerateRegisterSpedMFD(char *source, char *destiny, char *initialDate, char *finalDate, char *perfil, char *CFOP, char *codObsReleaseFiscal, char *taxPis, char *taxCofins);
int __stdcall Bematech_FI_GenerateRegisterSpedComplete(char *source, char *destiny, char *initialDate, char *finalDate, char *perfil, char *CFOP, char *codObsReleaseFiscal, char *taxPis, char *taxCofins, char *companyName, char *cityCodeIBGE);

//REGION_COMMUNICATION
bool __stdcall Bematech_FI_OpenPort(int *port);
int __stdcall Bematech_FI_SerialOpenPort();
int __stdcall Bematech_FI_SerialClosePort();

//REGION_TICKET
int __stdcall Bematech_FI_OpenShuttleCoupon(char *endValuePrint, char *emphasizedPrint, char *boarding, char *destiny, char *line, char *prefix, char *agent, char *agency, char *date, char *hour, char *seat, char *platform);
int __stdcall Bematech_FI_OpenShuttleCouponMFD(char *boarding, char *destiny, char *line, char *agency, char *date, char *hour, char *seat, char *platform, char *type, char *RG, char *name, char *address, char *UF);
int __stdcall Bematech_FI_CounterShuttleCoupon(char *counterShuttle);

//REGION_BANK
int __stdcall Bematech_FI_PrintPaymentCheck(char *bankNumber, char *value, char *favored, char *city, char *date, char *msg);
int __stdcall Bematech_FI_PrintPaymentCheckMFD(char *bankNumber, char *value, char *favored, char *city, char *date, char *msg, char *versePrint, char *lines);
int __stdcall Bematech_FI_PrintPaymentCheckMFDEx(char *bankNumber, char *value, char *favored, char *city, char *date, char *msg, char *source);
int __stdcall Bematech_FI_PrintPaymentCheckCopy();
int __stdcall Bematech_FI_PrintInformationPaymentCheckMFD(int position, int lines, char *msg);
int __stdcall Bematech_FI_IncludeCity(char *city, char *favored);
int __stdcall Bematech_FI_ReadPaymentCheckMFD(char *CMC7);
int __stdcall Bematech_FI_TurnPaymentCheckMFD();

//REGION_BARCODE
int __stdcall Bematech_FI_BarCodeCODABARMFD(char *code);
int __stdcall Bematech_FI_BarCodeCODE128MFD(char *code);
int __stdcall Bematech_FI_BarCodeCODE39MFD(char *code);
int __stdcall Bematech_FI_BarCodeCODE93MFD(char *code);
int __stdcall Bematech_FI_BarCodeEAN13MFD(char *code);
int __stdcall Bematech_FI_BarCodeEAN8MFD(char *code);
int __stdcall Bematech_FI_BarCodeISBNMFD(char *code);
int __stdcall Bematech_FI_BarCodeITFMFD(char *code);
int __stdcall Bematech_FI_BarCodeMSIMFD(char *code);
int __stdcall Bematech_FI_BarCodePDF417MFD(int correctionError, int height, int width, int colummns, char *code);
int __stdcall Bematech_FI_BarCodePLESSEYMFD(char *code);
int __stdcall Bematech_FI_BarCodeUPCAMFD(char *code);
int __stdcall Bematech_FI_BarCodeUPCEMFD(char *code);
int __stdcall Bematech_FI_ConfigureBarCodeMFD(int heigth, int width, int positionCharacter, int source, int margin);

//REGION_SINTEGRA
int __stdcall Bematech_FI_SintegraData(char *initialDate, char *finalDate);
int __stdcall Bematech_FI_SintegraDataMFD(char *initialDate, char *finalDate);
int __stdcall Bematech_FI_GenerateSintegraReportMFD(int report, char *origin, char *destiny, char *month, char *year, char *corporateName, char *address, char *number, char *complement, char *neighborhood, char *city, char *CEP, char *phone, char *fax, char *contact);
int __stdcall Bematech_FI_Type60Register();
int __stdcall Bematech_FI_SintegraReportMFD(int report, char *file, char *month, char *year, char *corporateName, char *address, char *number, char *complement, char *neighborhood, char *city, char *CEP, char *phone, char *fax, char *contact);
int __stdcall Bematech_FI_Analytic60TypeReport();
int __stdcall Bematech_FI_Analytic60TypeReportMFD();
int __stdcall Bematech_FI_Master60TypeReport();

//REGION_TEF
int __stdcall Bematech_FI_InitializeTEFMode();
int __stdcall Bematech_FI_UseNonFiscalLinkedVoucherTEF(char *text);
int __stdcall Bematech_FI_FinalizeTEFMode();

#if __cplusplus
	}
#endif

#endif // !defined(EA_E9E1BECE_57FB_4840_AC09_1091E2607F71__INCLUDED_)
