///////////////////////////////////////////////////////////
//  Reduced.h
//  Implementation of the Class Reduced
//  Created on:      17-mai-2011 14:42:57
//  Original author: adroaldo.filho
///////////////////////////////////////////////////////////

#if !defined(EA_87B43CCA_3007_4e96_B621_705DF125A179__INCLUDED_)
#define EA_87B43CCA_3007_4e96_B621_705DF125A179__INCLUDED_

#ifdef WIN32
	#ifndef __cplusplus
	#define DllExport __declspec(dllexport)
	#else
	#define DllExport extern "C" __declspec(dllexport)
	#endif
#else
	#define __stdcall
#endif

#if __cplusplus
	extern "C"
	{
#endif

typedef unsigned int uint32_t;

//FISCAL_INFORMATION
int __stdcall Bema_FI_ClicheProprietari(char *cliche);
int __stdcall Bema_FI_CompNFisNEmitMFD(char *voucher);
int __stdcall Bema_FI_ComprovNFiscNEmitid(char *voucher);
int __stdcall Bematech_FI_CompNaoFisNaoEmitMFD(char *voucher);
int __stdcall Bematech_FI_ComprovNaoFisNaoEmit(char *voucher);
int __stdcall Bema_FI_ContCompCreditMF(char *voucher);
int __stdcall Bematech_FI_ContCompCreditoMFD(char *voucher);
int __stdcall Bema_FI_ContCompCredito(char *voucher);
int __stdcall Bematech_FI_ContCompCredito(char *voucher);
int __stdcall Bema_FI_ContCupomFiscMFD(char *counter);
int __stdcall Bematech_FI_ContadorCupomFisMFD(char *counter);
int __stdcall Bema_FI_ContaTotalNaoFisc(char *counter);
int __stdcall Bematech_FI_ContTotNaoFiscal(char *counter);
int __stdcall Bema_FI_ContTotNaoFiscMFD(char *counter);
int __stdcall Bematech_FI_ContTotNaoFisMFD(char *counter);
int __stdcall Bema_FI_ContFitaDetalhMFD(char *counter);
int __stdcall Bematech_FI_ContFitaDetalheMFD(char *counter);
int __stdcall Bema_FI_ContFitaDetalhe(char *counter);
int __stdcall Bematech_FI_ContFitaDetalhe(char *counter);
int __stdcall Bema_FI_ContOpNFisCancMFD(char *counter);
int __stdcall Bema_FI_ContadOpNFisCancela(char *counter);
int __stdcall Bematech_FI_ContOpNaoFisCancMFD(char *counter);
int __stdcall Bematech_FI_ContadOpNaoFisCancel(char *counter);
int __stdcall Bema_FI_ContRelatGerenMFD(char *counter);
int __stdcall Bema_FI_ContadorRelatGerenc(char *counter);
int __stdcall Bematech_FI_ContRelatGerencMFD(char *counter);
int __stdcall Bematech_FI_ContadorRelatGerenc(char *counter);
int __stdcall Bema_FI_DadosUltimReducao(char *dataReduction);
int __stdcall Bema_FI_DadosUltimaRedMFD(char *dataReduction);
int __stdcall Bema_FI_DadosUltimRedCV0909(char *dataReduction);
int __stdcall Bematech_FI_DadosUltimaReducMFD(char *dataReduction);
int __stdcall Bematech_FI_DadosUltimaRedCV0909(char *dataReduction);
int __stdcall Bema_FI_DtHrGrUsuSWBasMFAd(char *userDate, char *sbDate, char *additionalLetter);
int __stdcall Bematech_FI_DtHrGrUsuSWBasMFAd(char *userDate, char *sbDate, char *additionalLetter);
int __stdcall Bema_FI_DataHoraImpressor(char *date, char *hour);
int __stdcall Bema_FI_DataHoraReducao(char *date, char *hour);
int __stdcall Bema_FI_DataHoraUltDocMFD(char *dateHour);
int __stdcall Bematech_FI_DataHoraUltDocMFD(char *dateHour);
int __stdcall Bema_FI_DataMovimento(char *date);
int __stdcall Bema_FI_DataMovUltRedMFD(char *date);
int __stdcall Bematech_FI_DataMovUltimaRedMFD(char *date);
int __stdcall Bema_FI_FlagsFiscais3MFD(short int *flag);
int __stdcall Bema_FI_FlagVinculacaoIss(int *flag1, int *flag2);
int __stdcall Bema_FI_GTUltimaReducMFD(char *totalGrid);
int __stdcall Bematech_FI_GTUltimaReducaoMFD(char *totalGrid);
int __stdcall Bema_FI_InicioFimCOOsMFD(char *COOBegin, char *COOEnd);
int __stdcall Bema_FI_InicioFimGTsMFD(char *tgBegin, char *tgEnd);
int __stdcall Bema_FI_InicioFimGTsCV0909(char *tgBegin, char *tgEnd);
int __stdcall Bema_FI_InscriEstadualMFD(char *IE);
int __stdcall Bema_FI_InscriEstadual(char *IE);
int __stdcall Bema_FI_InscricMunicipMFD(char *IM);
int __stdcall Bematech_FI_InscricMuniclMFD(char *IM);
int __stdcall Bema_FI_InscricMunicipal(char *IM);
int __stdcall Bematech_FI_InscricMunicl(char *IM);
int __stdcall Bema_FI_MarcModTipoImpMFD(char *brand, char *model, char *type);
int __stdcall Bematech_FI_MarcaModTipoImpMFD(char *brand, char *model, char *type);
int __stdcall Bema_FI_MinEmitDocFisMFD(char *minutes);
int __stdcall Bema_FI_MinEmitDocFisCV0909(char *minutes);
int __stdcall Bematech_FI_MinEmitDocFisMFD(char *minutes);
int __stdcall Bematech_FI_MinEmitDocFisCV0909(char *minutes);
int __stdcall Bema_FI_MinutosImprimindo(char *minutes);
int __stdcall Bema_FI_ModeloImpressora(char *model);
int __stdcall Bema_FI_ModeloVersaoImpres(char *model, char *version);
int __stdcall Bema_FI_MonitoramentoPape(int *lines);
int __stdcall Bema_FI_NumeroCuponsCance(char *couponNumber);
int __stdcall Bema_FI_NumeroIntervencoe(char *number);
int __stdcall Bema_FI_NumeroOperaNaoFis(char *operationsNumber);
int __stdcall Bematech_FI_NumOperacoesNaoFisc(char *operationsNumber);
int __stdcall Bema_FI_NumeroReducoes(char *reductionsNumber);
int __stdcall Bema_FI_NumSerieCripto(char *cryptoSerialNumber);
int __stdcall Bema_FI_NumSerieDescripto(char *cryptoSerialNumber, char *decryptSerialNumber);
int __stdcall Bema_FI_NumSerieMemoriMFD(char *serialNumber);
int __stdcall Bematech_FI_NumSerieMemoriaMFD(char *serialNumber);
int __stdcall Bema_FI_NumeroSerieMFD(char *serialNumberValue);
int __stdcall Bema_FI_NumeroSerieCV0909(char *serialNumber);
int __stdcall Bema_FI_NumeroSubstiPropr(char *substitutionsNumber);
int __stdcall Bematech_FI_NumSubstProprietario(char *substitutionsNumber);
int __stdcall Bema_FI_PercentLivreMFD(char *freePercentage);
int __stdcall Bema_FI_ReducRestantesMFD(char *reductions);
int __stdcall Bema_FI_ReducRestantes(char *reductions);
int __stdcall Bema_FI_RetornoAliquotas(char *taxes);
int __stdcall Bema_FI_RetornoAliquotasCV0909(char *taxes);
int __stdcall Bema_FI_RetAliqCV0909(char *taxes);
int __stdcall Bema_FI_RetornoImpressora(short int *ACK, short int *ST1, short int *ST2);
int __stdcall Bema_FI_RetImpressoraMFD(short int *ACK, short int *ST1, short int *ST2, short int *ST3);
int __stdcall Bema_FI_StatusEstendidMFD(short int *status);
int __stdcall Bema_FI_SubTotCompNFisMFD(char *subTotal);
int __stdcall Bematech_FI_SubTotCompNaoFisMFD(char *subTotal);
int __stdcall Bema_FI_TamanhoTotalMFD(char *size);
int __stdcall Bema_FI_TempoOperacionMFD(char *upTime);
int __stdcall Bema_FI_TempoOperacional(char *upTime);
int __stdcall Bema_FI_TempoRestCompMFD(char *remainingTime);
int __stdcall Bematech_FI_TempoRestCompMFD(char *remainingTime);
int __stdcall Bema_FI_TotalIcmsCupom(char *ICMS);
int __stdcall Bema_FI_TotalIssCupomMFD(char *ISS);
int __stdcall Bema_FI_UFProprietarioMFD(char *UF);
int __stdcall Bema_FI_UFProprietario(char *UF);
int __stdcall Bema_FI_UltimoItemVendido(char *itemNumber);
int __stdcall Bema_FI_ValorFormaPagto(char *form, char *value);
int __stdcall Bema_FI_ValorFormaPagMFD(char *form, char *value);
int __stdcall Bematech_FI_ValorFormaPagMFD(char *form, char *value);
int __stdcall Bema_FI_ValorPgUltimCupom(char *value);
int __stdcall Bema_FI_ValorTotNaoFiscal(char *totalizer, char *valueTotalizer);
int __stdcall Bema_FI_ValorTotNaoFisMFD(char *totalizer, char *valueTotalizer);
int __stdcall Bematech_FI_ValorTotNaoFisMFD(char *totalizer, char *valueTotalizer);
int __stdcall Bema_FI_VerificaAliquoIss(char *flags);
int __stdcall Bema_FI_VerifCanCup2HoMFD(char *flag);
int __stdcall Bema_FI_VerifVerEspecifCmd(char *ecfNumber);
int __stdcall Bema_FI_VerificaDepartame(char *departments);
int __stdcall Bema_FI_VerificEpromConec(char *flag);
int __stdcall Bema_FI_VerificaEstadoGav(short int *flag);
int __stdcall Bema_FI_VerificaEstadoImp(short int *ACK, short int *ST1, short int *ST2);
int __stdcall Bema_FI_VerifEstadoImpMFD(short int *ACK, short int *ST1, short int *ST2, short int *ST3);
int __stdcall Bematech_FI_VerificaEstadoImpMFD(short int *ACK, short int *ST1, short int *ST2, short int *ST3);
int __stdcall Bema_FI_VerifFlagCorteMFD(short int *flag);
int __stdcall Bema_FI_VerificaFormasPag(char *form);
int __stdcall Bema_FI_VerifFormasPagMFD(char *form);
int __stdcall Bema_FI_VeriFormasPagCV0909(char *form);
int __stdcall Bematech_FI_VerificaFormasPagMFD(char *form);
int __stdcall Bematech_FI_VeriFormasPagCV0909(char *form);
int __stdcall Bema_FI_VerificaImpresLig();
int __stdcall Bematech_FI_VerificaImpLigada();
int __stdcall Bema_FI_VerificaIndAliIss(char *index);
int __stdcall Bema_FI_VerificaModoOpera(char *mode);
int __stdcall Bema_FI_VerificaRecNaoFis(char *greetingsValue);
int __stdcall Bema_FI_VerifRecNaoFisMFD(char *greetingsValue);
int __stdcall Bema_FI_VerifRecNFisCV0909(char *greetingsValue);
int __stdcall Bematech_FI_VerificaRecNaoFisMFD(char *greetingsValue);
int __stdcall Bematech_FI_VerifRecNaoFisCV0909(char *greetingsValue);
int __stdcall Bema_FI_VerifReducaoZAuto(short int *flag);
int __stdcall Bematech_FI_VerificaRedZAuto(short int *flag);
int __stdcall Bema_FI_VerifRelatGerMFD(char *reports);
int __stdcall Bema_FI_VerificaRelatGerenc(char *reports);
int __stdcall Bematech_FI_VerificaRelatGerMFD(char *reports);
int __stdcall Bematech_FI_VerificaRelatGerenci(char *reports);
int __stdcall Bema_FI_VerifSensorPapMFD(char *flag);
int __stdcall Bema_FI_VerificaStatusChe(short int *status);
int __stdcall Bema_FI_VerificaTipoImpre(short int *printerType);
int __stdcall Bema_FI_VerificaTotNaoFis(char *totalizers);
int __stdcall Bema_FI_VerifTotNaoFisMFD(char *totalizers);
int __stdcall Bema_FI_VerifTotNFisCV0909(char *totalizers);
int __stdcall Bematech_FI_VerificaTotNaoFisMFD(char *totalizers);
int __stdcall Bematech_FI_VerifTotNaoFisCV0909(char *totalizers);
int __stdcall Bema_FI_VerificaTotParcia(char *totalizers);
int __stdcall Bema_FI_VerifTotParcMFD(char *totalizers);
int __stdcall Bematech_FI_VerificaTotParcMFD(char *totalizers);
int __stdcall Bema_FI_VerificaTruncamen(char *flag);
int __stdcall Bema_FI_VersaoFirmware(char *version);
int __stdcall Bema_FI_VersaoFirmwareMFD(char *version);
int __stdcall Bema_FI_VersaoFwCV0909(char *version);
int __stdcall Bema_FI_PreparaAbreCupom(char *coupon, char *couponCounter, short int *flag, char *date, char *hour, char *serialNumber, char *totalGrid);
int __stdcall Bema_FI_RetCasasDeciValUnit(char *decimals);
int __stdcall Bematech_FI_RetCasasDecValorUnit(char *decimals);
int __stdcall Bema_FI_RetCasasDecimaisQtd(char *decimals);
int __stdcall Bematech_FI_RetCasasDecimaisQntd(char *decimals);
int __stdcall Bema_FI_RetSiglaMunicipio(char *acronym);
int __stdcall Bema_FI_RetChavePublica(char *basicSoftwarePublicKey, char *eletronicFilesPublicKey, char *issuedFilesPublicKey, char *remoteAccessPublicKey, char *MIL_MITPublicKey);
int __stdcall Bema_FI_ICMSISSTotalizers(char *totalizers);
int __stdcall Bema_FI_ManagemReportTable(char *reports);
int __stdcall Bema_FI_TabelaFormasPgto(char *forms);
int __stdcall Bema_FI_QtdCuponsRestantes(char *amount);
int __stdcall Bema_FI_VerifURLTransmDados(char *url);
int __stdcall Bema_FI_TempoEmitOperCV0909(char *minutes, char *uptime);
int __stdcall Bema_FI_TabRelatGerenciais(char *reports);

//REGION_FISCAL_PRINTER
int __stdcall Bema_FI_AbreCompNFisVincu(char *paymentForm, char *value, char *couponNumber);
int __stdcall Bema_FI_AbrCompNFisVinMFD(char *paymentForm, char *value, char *couponNumber, char *CPF, char *name, char *address);
int __stdcall Bema_FI_AbrComNFisVinCV0909(int paymentSequence, char *paymentFormIndex, int quantityOfPayments, int paymentNumber, char *CPF, char *name, char *address);
int __stdcall Bematech_FI_AbreComNaoFisVincMFD(char *paymentForm, char *value, char *couponNumber, char *CPF, char *name, char *address);
int __stdcall Bematech_FI_AbrComNFisVincCV0909(int paymentSequence, char *paymentFormIndex, int quantityOfPayments, int paymentNumber, char *CPF, char *name, char *address);
int __stdcall Bema_FI_AbreRecNFiscalMFD(char *CPF, char *name, char *address);
int __stdcall Bema_FI_AbreRecNFisCV0909(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_AbreRecNaoFiscalMFD(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_AbreRecNFiscalCV0909(char *CPF, char *name, char *address);
int __stdcall Bema_FI_AbrRelatGerencMFD(char *totalizer);
int __stdcall Bema_FI_AbrRelatGerenCV0909(char *totalizer);
int __stdcall Bematech_FI_AbreRelatGerenMFD(char *totalizer);
int __stdcall Bematech_FI_AbreRelatGerenCV0909(char *totalizer);
int __stdcall Bema_FI_AbrSegViaNFVinMFD();
int __stdcall Bema_FI_AcionaGuilhotiMFD(short int mode);
int __stdcall Bema_FI_AcionaGuilhotCV0909();
int __stdcall Bema_FI_AcrescDescItemMFD(char *item, char *incrementDiscount, char *incrementDiscountType, char *incrementDiscountValue);
int __stdcall Bema_FI_AcresDescItemCV0909(char *item, char *incrementDiscount, char *incrementDiscountType, char *incrementDiscountValue);
int __stdcall Bematech_FI_AcrescDescItemMFD(char *item, char *incrementDiscount, char *incrementDiscountType, char *incrementDiscountValue);
int __stdcall Bematech_FI_AcrescDescItemCV0909(char *item, char *incrementDiscount, char *incrementDiscountType, char *incrementDiscountValue);
int __stdcall Bema_FI_AcrDescSubtotMFD(char *flag, char *type, char *value);
int __stdcall Bema_FI_AcrDescSubtotCV0909(char *flag, char *type, char *value);
int __stdcall Bema_FI_AcrDescSubtRecMFD(char *flag, char *type, char *value);
int __stdcall Bematech_FI_AcrDescSubRecMFD(char *flag, char *type, char *value);
int __stdcall Bema_FI_AcrItemNFiscalMFD(char *item, char *incrementDiscount, char *incrementDiscountType, char *incrementDiscountValue);
int __stdcall Bema_FI_AlteraSimboloMoed(char *currencySymbol);
int __stdcall Bema_FI_AumentaDescriItem(char *description);
int __stdcall Bema_FI_AutenticacaoMFD(char *lines, char *text);
int __stdcall Bema_FI_CanAcrDescItemMFD(char *flag, char *item);
int __stdcall Bema_FI_CanAcrDesItemCV0909(char *flag, char *item);
int __stdcall Bematech_FI_CancAcresDescItemMFD(char *flag, char *item);
int __stdcall Bematech_FI_CanAcrDescItemCV0909(char *flag, char *item);
int __stdcall Bema_FI_CanAcrDescSubtMFD(char *flag);
int __stdcall Bema_FI_CanAcrDesSubtCV0909(char *flag);
int __stdcall Bema_FI_CanAcDesSubRecMFD(char *flag);
int __stdcall Bematech_FI_CancAcrDescSubRecMFD(char *flag);
int __stdcall Bema_FI_CanAcrNaoFiscMFD(char *item, char *incrementDiscount);
int __stdcall Bema_FI_CancelaCupomMFD(char *CPF, char *name, char *address);
int __stdcall Bema_FI_CanCupomAtualCV0909();
int __stdcall Bema_FI_CancelImpreCheque();
int __stdcall Bema_FI_CancelItemPartially(char *item, char *quantity);
int __stdcall Bema_FI_CancelaItemAnteri();
int __stdcall Bema_FI_CancelaItemGeneri(char *item);
int __stdcall Bema_FI_CanItemNaoFiscMFD(char *item);
int __stdcall Bema_FI_CanItemNaoFiscal(char *item);
int __stdcall Bema_FI_CanRecNaoFiscMFD(char *CPF, char *name, char *address);
int __stdcall Bema_FI_CupomAdicionalMFD();
int __stdcall Bema_FI_DownloadSBCV0909(char *fileName);
int __stdcall Bema_FI_EfetuaFormaPagto(char *paymentForm, char *value);
int __stdcall Bema_FI_EfetFormPagDesFor(char *paymentForm, char *value, char *description);
int __stdcall Bema_FI_EfetFormaPagtoInd(char *paymentFormIndex, char *value);
int __stdcall Bematech_FI_EfeFormaPagIndice(char *paymentFormIndex, char *value);
int __stdcall Bema_FI_EfeFormPgtIndDesc(char *paymentFormIndex, char *value, char *description);
int __stdcall Bema_FI_EfetFormaPagtoMFD(char *paymentForm, char *value, char *payments, char *description);
int __stdcall Bematech_FI_EfeFormaPagamentoMFD(char *paymentForm, char *value, char *payments, char *description);
int __stdcall Bematech_FI_EfeFormaPagIndiceMFD(char *paymentFormIndex, char *value, char *payments, char *description);
int __stdcall Bematech_FI_EfeFormaPagIndiceCV0909(char *paymentFormIndex, char *value, char *payments, char *description, char *paymentFormCode);
int __stdcall Bema_FI_EfeFormPgtoIndMFD(char *paymentFormIndex, char *value, char *payments, char *description);
int __stdcall Bema_FI_EfeFormPgtoIndCV0909(char *paymentFormIndex, char *value, char *payments, char *description, char *paymentFormCode);
int __stdcall Bema_FI_EfetRecNFiscalMFD(char *totalizerIndex, char *value);
int __stdcall Bema_FI_EfeRecNFiscalCV0909(char *totalizerIndex, char *value);
int __stdcall Bematech_FI_EfetRecNaoFiscalMFD(char *totalizerIndex, char *value);
int __stdcall Bematech_FI_EfetRecNFiscalCV0909(char *totalizerIndex, char *value);
int __stdcall Bema_FI_EstornoFormasPaga(char *originForm, char *destinyForm, char *value);
int __stdcall Bema_FI_EstFormasPagaCV0909(char *originForm, char *destinyForm, char *value, int destinyPaymentSequence, char *message);
int __stdcall Bematech_FI_EstorFormasPagamento(char *originForm, char *destinyForm, char *value);
int __stdcall Bematech_FI_EstorFormasPagCV0909(char *originForm, char *destinyForm, char *value, int destinyPaymentSequence, char *message);
int __stdcall Bema_FI_EstorNFiscVincMFD(char *CPF, char *name, char *address);
int __stdcall Bema_FI_EstorNFisVincCV0909(char *CPF, char *name, char *address, char *COO);
int __stdcall Bematech_FI_EstorNaoFiscVincMFD(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_EstorNFiscVincCV0909(char *CPF, char *name, char *address, char *COO);
int __stdcall Bema_FI_EstNFVincPostMFD(char *paymentForm, char *value, char *couponCOO, char *CDCCOO, char *CPF, char *name, char *address);
int __stdcall Bema_FI_FechaCompNFiscVin();
int __stdcall Bematech_FI_FechaCompNaoFisVinc();
int __stdcall Bema_FI_FechaCupomResumid(char *paymentForm, char *message);
int __stdcall Bema_FI_FechaRecNFiscMFD(char *message);
int __stdcall Bema_FI_FechaRecNFiscCV0909(char *message, int cutter);
int __stdcall Bematech_FI_FechaRecNaoFiscalMFD(char *message);
int __stdcall Bematech_FI_FechaRecNaoFiscalCV0909(char *message, int cutter);
int __stdcall Bema_FI_FechaRelatGerenc();
int __stdcall Bema_FI_FechaRelGerCV0909(int cutter);
int __stdcall Bematech_FI_FechaRelatGerencial();
int __stdcall Bematech_FI_FechRelatGerenCV0909(int cutter);
int __stdcall Bema_FI_FechamentoDoDia();
int __stdcall Bema_FI_FormatoDadosMFD(char *MFDFile, char *destiny, char *format, char *downloadType, char *initialData, char *finalData, char *user);
int __stdcall Bema_FI_ImpresFitaDetalhe(char *type, char *initialData, char *finalData, char *user);
int __stdcall Bema_FI_ImpresFitaDetCV0909(char *type, char *initialData, char *finalData);
int __stdcall Bema_FI_ImprimeClicheMFD();
int __stdcall Bema_FI_ImprimeConfigImp();
int __stdcall Bema_FI_ImprimeDeptos();
int __stdcall Bema_FI_IniciaFechamenCup(char *incrementDiscount, char *incrementDiscountType, char *incrementDiscountValue);
int __stdcall Bema_FI_InicFechaCupomMFD(char *incrementDiscount, char *incrementDiscountType, char *incrementValue, char *discountValue);
int __stdcall Bema_FI_IniFechRecNFisMFD(char *incrementDiscount, char *incrementDiscountType, char *incrementValue, char *discountValue);
int __stdcall Bematech_FI_IniFechaRecNaoFisMFD(char *incrementDiscount, char *incrementDiscountType, char *incrementValue, char *discountValue);
int __stdcall Bema_FI_LeituraMemFiscDat(char *initialDate, char *finalDate);
int __stdcall Bema_FI_LeitMemFisDataMFD(char *initialDate, char *finalDate, char *readFlag);
int __stdcall Bema_FI_LeiMemFisDataCV0909(char *initialDate, char *finalDate, char *readFlag);
int __stdcall Bematech_FI_LeitMemFisDataMFD(char *initialDate, char *finalDate, char *readFlag);
int __stdcall Bematech_FI_LeitMemFisDataCV0909(char *initialDate, char *finalDate, char *readFlag);
int __stdcall Bema_FI_LeituraMemFiscRed(char *initialReduction, char *finalReduction);
int __stdcall Bema_FI_LeitMemFisReduMFD(char *initialReduction, char *finalReduction, char *readFlag);
int __stdcall Bema_FI_LeitMemFisRedCV0909(char *initialReduction, char *finalReduction, char *readFlag);
int __stdcall Bematech_FI_LeitMemFisReduMFD(char *initialReduction, char *finalReduction, char *readFlag);
int __stdcall Bematech_FI_LeitMemFisReduCV0909(char *initialReduction, char *finalReduction, char *readFlag);
int __stdcall Bema_FI_LeituMemFisSerDat(char *initialDate, char *finalDate);
int __stdcall Bema_FI_LeMemFisSerDatMFD(char *initialDate, char *finalDate, char *readFlag);
int __stdcall Bema_FI_LeMeFisSerDatCV0909(char *initialDate, char *finalDate, char *readFlag);
int __stdcall Bematech_FI_LeitMemFisSerDataMFD(char *initialDate, char *finalDate, char *readFlag);
int __stdcall Bematech_FI_LeiMeFisSerDatCV0909(char *initialDate, char *finalDate, char *readFlag);
int __stdcall Bema_FI_LeituMemFisSerRed(char *initialReduction, char *finalReduction);
int __stdcall Bema_FI_LeMemFisSerRedMFD(char *initialReduction, char *finalReduction, char *readFlag);
int __stdcall Bema_FI_LeMemFiSerRedCV0909(char *initialReduction, char *finalReduction, char *readFlag);
int __stdcall Bematech_FI_LeitMemFisSerRedMFD(char *initialReduction, char *finalReduction, char *readFlag);
int __stdcall Bematech_FI_LeMemFisSerRedCV0909(char *initialReduction, char *finalReduction, char *readFlag);
int __stdcall Bema_FI_LeituraXSerial(void);
int __stdcall Bema_FI_MapaResumoMFD(void);
int __stdcall Bema_FI_RecebimeNaoFiscal(char *totalizerIndex, char *receivingValue, char *paymentForm);
int __stdcall Bema_FI_ReimpNFiscVincMFD();
int __stdcall Bema_FI_ReimpNFisVincCV0909();
int __stdcall Bematech_FI_ReimpNaoFisVincMFD();
int __stdcall Bematech_FI_ReimpNaoFisVinCV0909();
int __stdcall Bema_FI_RelatorioGerencia(char *text);
int __stdcall Bema_FI_ResetaImpressora();
int __stdcall Bema_FI_SegViaNFisVincMFD();
int __stdcall Bema_FI_SegViaNFiVincCV0909();
int __stdcall Bematech_FI_SegViaNaoFisVincMFD();
int __stdcall Bematech_FI_SegViaNFisVincCV0909();
int __stdcall Bema_FI_SubTotalizaCupMFD();
int __stdcall Bema_FI_SubTotalizaRecMFD();
int __stdcall Bematech_FI_SubTotalizaRecMFD();
int __stdcall Bema_FI_TerminaFechaCupom(char *message);
int __stdcall Bema_FI_TerFechaCupomCV0909(char *message, int additionalCoupon, int cutter);
int __stdcall Bematech_FI_TerminaFechaCupom(char *message);
int __stdcall Bematech_FI_TermFechaCupomCV0909(char *message, int additionalCoupon, int cutter);
int __stdcall Bema_FI_TermiCupCodBarMFD(const char *tmpMessage, const char *codeType, const char *code, int height, int tmpWidth, int characterPosition, int source, int margin, int fixErrors, int columns);
int __stdcall Bema_FI_TotalizaRecMFD();
int __stdcall Bematech_FI_TotalizaRecMFD();
int __stdcall Bema_FI_UsaCompNaoFisVinc(char *text);
int __stdcall Bematech_FI_UsaCompNaoFisVinc(char *text);
int __stdcall Bema_FI_UsaRelatGerencMFD(char *text);
int __stdcall Bema_FI_UsaRelatGerenCV0909(char *text);
int __stdcall Bematech_FI_UsaRelatGerencialMFD(char *text);
int __stdcall Bematech_FI_UsaRelatGerencCV0909(char *text);
int __stdcall Bema_FI_VendeItemArredMFD(char *code, char *description, char *tax, char *unitOfMeasure, char *quantityFractionated, char *unitary, char *incrementValue, char *discountValue, bool rounds);
int __stdcall Bema_FI_VendeItemDepartam(char *code, char *description, char *tax, char *unitValue, char *quantity, char *incrementValue, char *discountValue, char *indexDepartment, char *unitOfMeasure);
int __stdcall Bema_FI_VendeItemDepto(char *code, char *description, char *tax, char *unitValue, char *quantity, char *incrementValue, char *discountValue, char *indexDepartment, char *unitOfMeasure);
int __stdcall Bema_FI_TotalizaCupomMFD();
int __stdcall Bema_FI_UsaUnidadeMedida(char *unitOfMeasure);

//REGION_PROGRAMATION
int __stdcall Bema_FI_ProgIdConsumidor(char *CPF, char *name, char *address);
int __stdcall Bema_FI_ProgramaAliquota(char *taxAmount, int typeofAmount);
int __stdcall Bema_FI_ProgAliquotaCV0909(char *taxAmount, char *taxIndex);
int __stdcall Bema_FI_ProgAliquoEspCV0909(char *taxF, char *taxI, char *taxN, char *taxFS, char *taxIS, char *taxNS);
int __stdcall Bema_FI_ProgramaHoraVerao(void);
int __stdcall Bema_FI_ProgHoraVeraoCV0909(int mode);
int __stdcall Bema_FI_NomeTotNaoSujIcms(int index, char *totalizer);
int __stdcall Bema_FI_NomTotNSuIcmsCV0909(int index, char *totalizer, char *inOrOut);
int __stdcall Bematech_FI_NomeTotalNaoSujIcms(int index, char *totalizer);
int __stdcall Bematech_FI_NomTotNSujIcmsCV0909(int index, char *totalizer, char *inOrOut);
int __stdcall Bema_FI_ProgramaArredonda();
int __stdcall Bema_FI_ProgramaTruncamen();
int __stdcall Bema_FI_NomeiaDepartament(int index, char *department);
int __stdcall Bema_FI_LinhasEntreCupons(int lines);
int __stdcall Bema_FI_EspacoEntreLinhas(int dots);
int __stdcall Bema_FI_ProgramaMoedaSing(char *singularCurrency);
int __stdcall Bema_FI_ProgramaMoedaPlur(char *pluralCurrency);
int __stdcall Bema_FI_ProgIdAplicatMFD(char *idApp);
int __stdcall Bema_FI_ProgIdAplicatCV0909(char *idApp);
int __stdcall Bema_FI_ForcaImpactoAgulh(short int impactValue);
int __stdcall Bema_FI_ProgCaracAutentic(char *parameters);
int __stdcall Bema_FI_AtDesAlinhaEsqMFD(short int flag);
int __stdcall Bematech_FI_AtiDesAliEsquerdaMFD(short int flag);
int __stdcall Bema_FI_AtDesCanCup2HrMFD(int flag);
int __stdcall Bema_FI_AtDesCorteProxMFD();
int __stdcall Bematech_FI_AtiDesCorteProxMFD();
int __stdcall Bema_FI_AtDesCorteTotalMFD(short int flag);
int __stdcall Bema_FI_AtDesGuilhotinMFD(short int flag);
int __stdcall Bema_FI_AtDesSPoucoPapMFD(int flag);
int __stdcall Bema_FI_AtDesTratONOFFMFD(short int flag);
int __stdcall Bematech_FI_AtiDesTratONOFFMFD(short int flag);
int __stdcall Bema_FI_AtDesVenUmaLinMFD(short int flag);
int __stdcall Bematech_FI_AtiDesVendaUmaLinMFD(short int flag);
int __stdcall Bema_FI_AvaPapAcionaGuiMFD(short int lines, short int mode);
int __stdcall Bema_FI_ConfigCorteGuiMFD(int time);
int __stdcall Bema_FI_NomRelatGerencMFD(char *index, char *description);
int __stdcall Bema_FI_NomRelatGerenCV0909(char *index, char *description);
int __stdcall Bematech_FI_NomRelatGerencialMFD(char *index, char *description);
int __stdcall Bematech_FI_NomRelatGerencCV0909(char *index, char *description);
int __stdcall Bema_FI_ProgFormaPagtoMFD(char *paymentForm, char *operationTef);
int __stdcall Bema_FI_ProgFormaPgtoCV0909(char *paymentIndex, char *paymentForm, int linkedCCD);
int __stdcall Bematech_FI_ProgFormaPagamentMFD(char *paymentForm, char *operationTef);
int __stdcall Bematech_FI_ProgFormaPgtoCV0909(char *paymentIndex, char *paymentForm, int linkedCCD);
int __stdcall Bema_FI_ProgQtdDocsAutoriz(char *data);
int __stdcall Bematech_FI_ProgQtdDocsAutorizad(char *data);
int __stdcall Bema_FI_ProgramaOperador(char *data);

//REGION_UTILS
void __stdcall Bema_FI_CriptoDescripto(char *buffer, uint32_t sizeBuffer, char *key, uint32_t sizeKey);
int __stdcall Bema_FI_SelecionaXMLLocal();
int __stdcall Bema_FI_SelecionaIniLocal();
int __stdcall Bema_FI_HabDesabRetEstMFD(char *extendedFlag);
int __stdcall Bematech_FI_HabDesRetMFD(char *extendedFlag);
int __stdcall Bematech_FI_HabDesbRetEstMFD(char *extendedFlag);

//REGION_PAF
int __stdcall Bema_FI_NomeiaRelatorios(char *name);
int __stdcall Bema_FI_AbrDocAuxVenda(char *index, char *title, char *DAVNumber, char *issuerName, char *issuerCNPJCPF, char *recipientName, char *recipientCNPJCPF);
int __stdcall Bema_FI_AbrRelaMeiosPgto(char *index);
int __stdcall Bema_FI_DAVEmitidosArquivo(char *fileName, char *initialDate, char *finalDate, char *publicKey, char *privateKey);
int __stdcall Bema_FI_DAVEmitRelaGerenci(char *index, char *initialDate, char *finalDate);
int __stdcall Bema_FI_FechaDocAuxVenda(char *total);
int __stdcall Bema_FI_FechaRelaMeiosPgto();
int __stdcall Bema_FI_GTCriptografado(char *totalGrid);
int __stdcall Bema_FI_GTDescriptografado(char *encryptedTotalGrid, char *decryptTotalGrid);
int __stdcall Bema_FI_IdentificaPAFECF(char *index, char *reportNumber, char *developerCNPJ, char *companyName, char *address, char *phone, char *contact, char *tradeName, char *version, char *mainExecutable, char *mainExecutableMD5, char *otherFiles, char *otherFilesMD5, char *registrationNumber);
int __stdcall Bema_FI_LeiMFisSDataPAFECF(char *initialDate, char *finalDate, char *readFlag, char *publicKey, char *privateKey);
int __stdcall Bema_FI_LeiMFisSRedPAFECF(char *initialReduction, char *finalReduction, char *readFlag, char *publicKey, char *privateKey);
int __stdcall Bema_FI_NomeRelDAVEmitidos();
int __stdcall Bema_FI_NomeRelDocAuxVenda();
int __stdcall Bema_FI_NomeRelIdentPAFECF();
int __stdcall Bema_FI_NomeRelMeiosDePgto();
int __stdcall Bema_FI_NomeRelatPAFECF();
int __stdcall Bema_FI_TerFechCupomPVenda(char *MD5, char *preSaleNumber, char *promotionalMessage);
int __stdcall Bema_FI_UsaDocAuxVenda(char *item, char *unitValue, char *totalValue);
int __stdcall Bema_FI_UsaRelMeiosPgto(char *identification, char *documentType, char *accumulatedValue, char *date);

//REGION_CAT52
int __stdcall Bema_FI_GeraRegCAT52MFD(char *MFDFile, char *date);
int __stdcall Bema_FI_GeraRegCAT52MFDEx(char *source, char *date, char *destiny);
void __stdcall Bema_FI_AlerParamRegTipoE(int parametrization);

//REGION_SPED
int __stdcall Bema_FI_GeraRegSpedMFD(char *source, char *destiny, char *initialDate, char *finalDate, char *perfil, char *CFOP, char *codObsReleaseFiscal, char *taxPis, char *taxCofins);

//REGION_COMMUNICATION
int __stdcall Bema_FI_AbrePortaSerial();
int __stdcall Bema_FI_FechaPortaSerial();

//REGION_TICKET
int __stdcall Bema_FI_AbreBilhetePassag(char *endValuePrint, char *emphasizedPrint, char *boarding, char *destiny, char *line, char *prefix, char *agent, char *agency, char *date, char *hour, char *seat, char *platform);
int __stdcall Bema_FI_AbreBilhetePasMFD(char *boarding, char *destiny, char *line, char *agency, char *date, char *hour, char *seat, char *platform, char *type, char *RG, char *name, char *address, char *UF);
int __stdcall Bema_FI_ContBilhetePassag(char *counterShuttle);

//REGION_BANK
int __stdcall Bema_FI_ImprimeChequeMFD(char *bankNumber, char *value, char *favored, char *city, char *date, char *msg, char *versePrint, char *lines);
int __stdcall Bema_FI_ImprimeChequeMFDEx(char *bankNumber, char *value, char *favored, char *city, char *date, char *msg, char *source);
int __stdcall Bema_FI_ImprimeCopiaChequ();
int __stdcall Bema_FI_ImprimeInfoCheqMFD(int position, int lines, char *msg);
int __stdcall Bema_FI_IncluiCidadeFavor(char *city, char *favored);
int __stdcall Bema_FI_LeituraChequeMFD(char *CMC7);

//REGION_BARCODE
int __stdcall Bema_FI_CodBarCODABARMFD(char *code);
int __stdcall Bema_FI_CodBarCODE128MFD(char *code);
int __stdcall Bema_FI_CodBarCODE39MFD(char *code);
int __stdcall Bema_FI_CodBarCODE93MFD(char *code);
int __stdcall Bema_FI_CodBarEAN13MFD(char *code);
int __stdcall Bema_FI_CodBarEAN8MFD(char *code);
int __stdcall Bema_FI_CodBarISBNMFD(char *code);
int __stdcall Bema_FI_CodBarITFMFD(char *code);
int __stdcall Bema_FI_CodBarMSIMFD(char *code);
int __stdcall Bema_FI_CodBarPDF417MFD(int correctionError, int height, int width, int colummns, char *code);
int __stdcall Bema_FI_CodBarPLESSEYMFD(char *code);
int __stdcall Bema_FI_CodBarUPCAMFD(char *code);
int __stdcall Bema_FI_CodBarUPCEMFD(char *code);
int __stdcall Bema_FI_ConfigCodBarMFD(int heigth, int width, int positionCharacter, int source, int margin);

//REGION_SINTEGRA
int __stdcall Bema_FI_DadosSintegraMFD(char *initialDate, char *finalDate);
int __stdcall Bema_FI_GerRelSintegraMFD(int report, char *origin, char *destiny, char *month, char *year, char *corporateName, char *address, char *number, char *complement, char *neighborhood, char *city, char *CEP, char *phone, char *fax, char *contact);
int __stdcall Bema_FI_RegistrosTipo60();
int __stdcall Bema_FI_RelatSintegraMFD(int report, char *file, char *month, char *year, char *corporateName, char *address, char *number, char *complement, char *neighborhood, char *city, char *CEP, char *phone, char *fax, char *contact);
int __stdcall Bema_FI_RelatTipo60A();
int __stdcall Bema_FI_RelatTipo60AMFD();
int __stdcall Bematech_FI_RelatTipo60AnaliMFD();
int __stdcall Bema_FI_RelatTipo60M();
int __stdcall Bematech_FI_RelatTipo60Mestre();

//REGION_NFCE
int __stdcall Bema_FI_VendeItemCompJSON(char *parameter);
int __stdcall Bema_FI_TerFechaCupomNFCe(char *message, char *taxes);
int __stdcall Bema_FI_ChaveAcessoNFCe(char *index, char *counter, char *accessKey);
int __stdcall Bema_FI_UltChavAcessoNFCe(char *accessKey);
int __stdcall Bema_FI_StatusUltimaNFCe(char *status);
int __stdcall Bema_FI_StatUltCancNFCe(char *status);
int __stdcall Bema_FI_ProgContadorNFCe(char *index, char *counter);
int __stdcall Bema_FI_DadosEnvioNFCe(char *layoutType, char *sendType, char *email);
int __stdcall Bema_FI_ProtUltimaNFCe(char *protocol, char *dateHour);
int __stdcall Bema_FI_EfetPagtoNFCEex(char *paymentForm, char *value, char *licensingCNPJ, char *licensingCode, char *authorizationCode, char *integrationCode);

#if __cplusplus
	}
#endif

#endif // !defined(EA_87B43CCA_3007_4e96_B621_705DF125A179__INCLUDED_)
