///////////////////////////////////////////////////////////
//  Portuguese.h
//  Implementation of the Class Portuguese
//  Created on:      17-mai-2011 14:38:26
//  Original author: adroaldo.filho
///////////////////////////////////////////////////////////

#if !defined(EA_D7EC8BD3_F3BA_4c22_B76D_CB11BBBF52A0__INCLUDED_)
#define EA_D7EC8BD3_F3BA_4c22_B76D_CB11BBBF52A0__INCLUDED_

#ifdef WIN32
	#ifndef __cplusplus
	#define DllExport __declspec(dllexport)
	#else
	#define DllExport extern "C" __declspec(dllexport)
	#endif
#else
	#define __stdcall
#endif

#if __cplusplus
	extern "C"
	{
#else
	typedef int bool;
	#define true 1
	#define false 0
#endif

//FISCAL_INFORMATION
int __stdcall Bematech_FI_Acrescimos(char *incrementValue);
int __stdcall Bematech_FI_XMLConfiguration(char *port, int protocol, int nivelLog, char *strName);
int __stdcall Bematech_FI_AcrescimosICMS(char *incrementValue);
int __stdcall Bematech_FI_AcrescimosISS(char *incrementValue);
int __stdcall Bematech_FI_Cancelamentos(char *cancellationValue);
int __stdcall Bematech_FI_CancelamentosICMS(char *cancellationValue);
int __stdcall Bematech_FI_CancelamentosISS(char *cancellationValue);
int __stdcall Bematech_FI_ClicheProprietario(char *cliche);
int __stdcall Bematech_FI_ContadorComprovantesCreditoMFD(char *voucher);
int __stdcall Bematech_FI_ContadorComprovantesCredito(char *voucher);
int __stdcall Bematech_FI_ComprovantesNaoFiscaisNaoEmitidosMFD(char *voucher);
int __stdcall Bematech_FI_ComprovantesNaoFiscaisNaoEmitidos(char *voucher);
int __stdcall Bematech_FI_ContadorCupomFiscalMFD(char *counter);
int __stdcall Bematech_FI_ContadorCupomFiscal(char *counter);
int __stdcall Bematech_FI_ContadorFitaDetalheMFD(char *counter);
int __stdcall Bematech_FI_ContadorFitaDetalhe(char *counter);
int __stdcall Bematech_FI_ContadorOperacoesNaoFiscaisCanceladasMFD(char *counter);
int __stdcall Bematech_FI_ContadorOperacoesNaoFiscaisCanceladas(char *counter);
int __stdcall Bematech_FI_ContadorRelatoriosGerenciaisMFD(char *counter);
int __stdcall Bematech_FI_ContadorRelatoriosGerenciais(char *counter);
int __stdcall Bematech_FI_CriptografiaGrandeTotal(char *cryptoTotalGrid);
int __stdcall Bematech_FI_DataHoraImpressora(char *date, char *hour);
int __stdcall Bematech_FI_DataMovimento(char *date);
int __stdcall Bematech_FI_DadosUltimaReducao(char *dataReduction);
int __stdcall Bematech_FI_DadosUltimaReducaoMFD(char *dataReduction);
int __stdcall Bematech_FI_DadosUltimaReducaoCV0909(char *dataReduction);
int __stdcall Bematech_FI_DadosReducaoCV0909(char *reductionNumber, char *dataReduction);
int __stdcall Bematech_FI_Descontos(char *discountValue);
int __stdcall Bematech_FI_DescontosICMS(char *discountValue);
int __stdcall Bematech_FI_DescontosISS(char *discountValue);
int __stdcall Bematech_FI_EnderecoComercial(char *address);
int __stdcall Bematech_FI_GrandeTotal(char *totalGrid);
int __stdcall Bematech_FI_InscricaoEstadualMFD(char *IE);
int __stdcall Bematech_FI_InscricaoEstadual(char *IE);
int __stdcall Bematech_FI_InscricaoMunicipalMFD(char *IM);
int __stdcall Bematech_FI_InscricaoMunicipal(char *IM);
int __stdcall Bematech_FI_MarcaModeloTipoImpressoraMFD(char *brand, char *model, char *type);
int __stdcall Bematech_FI_MinutosEmitindoDocumentosFiscaisMFD(char *minutes);
int __stdcall Bematech_FI_MinutosEmitindoDocumentosFiscaisCV0909(char *minutes);
int __stdcall Bematech_FI_ModeloImpressora(char *model);
int __stdcall Bematech_FI_NomeFantasia(char *name);
int __stdcall Bematech_FI_NumeroCupom(char *couponNumber);
int __stdcall Bematech_FI_NumeroCupomCV0909(char *couponNumber);
int __stdcall Bematech_FI_NumeroCuponsCancelados(char *couponNumber);
int __stdcall Bematech_FI_NumeroIntervencoes(char *number);
int __stdcall Bematech_FI_NumeroLoja(char *storeNumber);
int __stdcall Bematech_FI_NumeroOperacoesNaoFiscais(char *operationsNumber);
int __stdcall Bematech_FI_NumeroOperacoesNaoFiscaisCV0909(char *operationsNumber);
int __stdcall Bematech_FI_NumeroReducoes(char *reductionsNumber);
int __stdcall Bematech_FI_NumeroSerie(char *serialNumber);
int __stdcall Bematech_FI_NumeroSerieMFD(char *serialNumberValue);
int __stdcall Bematech_FI_NumeroSerieCV0909(char *serialNumber);
int __stdcall Bematech_FI_QuantidadeCuponsRestantes(char *amount);
int __stdcall Bematech_FI_RazaoSocial(char *name);
int __stdcall Bematech_FI_ReducoesRestantesMFD(char *reductions);
int __stdcall Bematech_FI_ReducoesRestantes(char *reductions);
int __stdcall Bematech_FI_RetornaCasasDecimaisValorUnitario(char *decimals);
int __stdcall Bematech_FI_RetornaCasasDecimaisQuantidade(char *decimals);
int __stdcall Bematech_FI_RetornaChavePublica(char *basicSoftwarePublicKey, char *eletronicFilesPublicKey, char *issuedFilesPublicKey, char *remoteAccessPublicKey, char *MIL_MITPublicKey);
int __stdcall Bematech_FI_RetornaChavePublicaAssinaturaArquivos(char *eletronicFilesPublicKey);
int __stdcall Bematech_FI_RetornaSiglaMunicipio(char *acronym);
int __stdcall Bematech_FI_RetornaVersaoESCECF(char *version);
int __stdcall Bematech_FI_RetornoAliquotas(char *taxes);
int __stdcall Bematech_FI_RetornoAliquotasCV0909(char *taxes);
int __stdcall Bematech_FI_SimboloMoeda(char *currencySymbol);
int __stdcall Bematech_FI_VerificaEstadoBobinaPapel(char *status);
int __stdcall Bematech_FI_StatusMovimento(char *movementDate, int status, char *initialCOO, char *initialTotalGrid);
int __stdcall Bematech_FI_TabelaFormasPagamento(char *forms);
int __stdcall Bematech_FI_TabelaRelatoriosGerenciais(char *reports);
int __stdcall Bematech_FI_TempoEmitindoOperacionalCV0909(char *minutes, char *uptime);
int __stdcall Bematech_FI_TempoOperacionalMFD(char *upTime);
int __stdcall Bematech_FI_TempoOperacional(char *upTime);
int __stdcall Bematech_FI_TotalizadoresICMSISS(char *totalizers);
int __stdcall Bematech_FI_TotalizadoresFIN(char *totalizers);
int __stdcall Bematech_FI_UFProprietarioMFD(char *UF);
int __stdcall Bematech_FI_UFProprietario(char *UF);
int __stdcall Bematech_FI_VendaBruta(char *grossSales);
int __stdcall Bematech_FI_VendaLiquida(char *netSales);
int __stdcall Bematech_FI_VerificaFormasPagamento(char *form);
int __stdcall Bematech_FI_VerificaFormasPagamentoMFD(char *form);
int __stdcall Bematech_FI_VerificaFormasPagamentoCV0909(char *form);
int __stdcall Bematech_FI_VerificaRecebimentoNaoFiscal(char *greetingsValue);
int __stdcall Bematech_FI_VerificaRecebimentoNaoFiscalMFD(char *greetingsValue);
int __stdcall Bematech_FI_VerificaRecebimentoNaoFiscalCV0909(char *greetingsValue);
int __stdcall Bematech_FI_VerificaRelatorioGerencialMFD(char *reports);
int __stdcall Bematech_FI_VerificaRelatorioGerencial(char *reports);
int __stdcall Bematech_FI_VerificaURLTransmissaoDados(char *url);
int __stdcall Bematech_FI_VerificaTipoImpressora(short int *printerType);
int __stdcall Bematech_FI_VerificaTipoImpressoraStr(char *printerType);
int __stdcall Bematech_FI_VerificaTotalizadoresNaoFiscais(char *totalizers);
int __stdcall Bematech_FI_VerificaTotalizadoresNaoFiscaisIO(char *totalizers);
int __stdcall Bematech_FI_VerificaTotalizadoresNaoFiscaisMFD(char *totalizers);
int __stdcall Bematech_FI_VerificaTotalizadoresNaoFiscaisCV0909(char *totalizers);
int __stdcall Bematech_FI_VerificaVersaoEspecificacaoComandos(char *ecfNumber);
int __stdcall Bematech_FI_VersaoDll(char *version);
int __stdcall Bematech_FI_VersaoFirmware(char *version);
int __stdcall Bematech_FI_VersaoFirmwareMFD(char *version);
int __stdcall Bematech_FI_VersaoFirmwareCV0909(char *version);
int __stdcall Bematech_FI_VendaLiquida(char *netSales);
int __stdcall Bematech_FI_VerificaEstadoTampa(char *status);
int __stdcall Bematech_FI_VerificaZPendente(char *status);
int __stdcall Bematech_FI_VerificaContextoImpressora(char *status);
int __stdcall Bematech_FI_ContadoresTotalizadoresNaoFiscais(char *counter);
int __stdcall Bematech_FI_ContadoresTotalizadoresNaoFiscaisMFD(char *counter);
int __stdcall Bematech_FI_DataHoraGravacaoUsuarioSWBasicoMFAdicional(char *userDate, char *sbDate, char *additionalLetter);
int __stdcall Bematech_FI_DataHoraReducao(char *date, char *hour);
int __stdcall Bematech_FI_DataHoraUltimoDocumentoMFD(char *dateHour);
int __stdcall Bematech_FI_DataMovimentoUltimaReducaoMFD(char *date);
int __stdcall Bematech_FI_FlagsFiscais(short int *flag);
int __stdcall Bematech_FI_FlagsFiscaisStr(char *flag);
int __stdcall Bematech_FI_FlagsFiscais3MFD(short int *flag);
int __stdcall Bematech_FI_FlagsVinculacaoIss(int *flag1, int *flag2);
int __stdcall Bematech_FI_GrandeTotalUltimaReducaoMFD(char *totalGrid);
int __stdcall Bematech_FI_InicioFimCOOsMFD(char *COOBegin, char *COOEnd);
int __stdcall Bematech_FI_InicioFimGTsMFD(char *tgBegin, char *tgEnd);
int __stdcall Bematech_FI_InicioFimGTsCV0909(char *tgBegin, char *tgEnd);
int __stdcall Bematech_FI_MarcaImpressora(char *brand);
int __stdcall Bematech_FI_MinutosImprimindo(char *minutes);
int __stdcall Bematech_FI_MinutosLigada(char *minutes);
int __stdcall Bematech_FI_ModeloVersaoImpressora(char *model, char *version);
int __stdcall Bematech_FI_MonitoramentoPapel(int *lines);
int __stdcall Bematech_FI_NumeroCaixa(char *number);
int __stdcall Bematech_FI_NumeroSerieCriptografado(char *cryptoSerialNumber);
int __stdcall Bematech_FI_NumeroSerieDescriptografado(char *cryptoSerialNumber, char *decryptSerialNumber);
int __stdcall Bematech_FI_NumeroSerieMemoriaMFD(char *serialNumber);
int __stdcall Bematech_FI_NumeroSubstituicoesProprietario(char *substitutionsNumber);
int __stdcall Bematech_FI_PercentualLivreMFD(char *freePercentage);
int __stdcall Bematech_FI_PreparaAbreCupom(char *coupon, char *couponCounter, short int *flag, char *date, char *hour, char *serialNumber, char *totalGrid);
int __stdcall Bematech_FI_RetornoImpressora(short int *ACK, short int *ST1, short int *ST2);
int __stdcall Bematech_FI_RetornoImpressoraStr(char *ACK, char *ST1, char *ST2);
int __stdcall Bematech_FI_RetornoImpressoraMFD(short int *ACK, short int *ST1, short int *ST2, short int *ST3);
int __stdcall Bematech_FI_RetornoImpressoraCV0909(short int *CAT, short int *RET1, short int *RET2, short int *RET3, short int *RET4);
int __stdcall Bematech_FI_StatusEstendidoMFD(short int *status);
int __stdcall Bematech_FI_SubTotalComprovanteNaoFiscalMFD(char *subTotal);
int __stdcall Bematech_FI_SubTotal(char *subTotal);
int __stdcall Bematech_FI_TamanhoTotalMFD(char *size);
int __stdcall Bematech_FI_TempoRestanteComprovanteMFD(char *remainingTime);
int __stdcall Bematech_FI_TipoImpressora(char *type);
int __stdcall Bematech_FI_TotalIcmsCupom(char *ICMS);
int __stdcall Bematech_FI_TotalIssCupomMFD(char *ISS);
int __stdcall Bematech_FI_TotalLivreMFD(char *size);
int __stdcall Bematech_FI_UltimoItemVendido(char *itemNumber);
int __stdcall Bematech_FI_ValorFormaPagamento(char *form, char *value);
int __stdcall Bematech_FI_ValorFormaPagamentoMFD(char *form, char *value);
int __stdcall Bematech_FI_ValorPagoUltimoCupom(char *value);
int __stdcall Bematech_FI_ValorTotalizadorNaoFiscal(char *totalizer, char *valueTotalizer);
int __stdcall Bematech_FI_ValorTotalizadorNaoFiscalMFD(char *totalizer, char *valueTotalizer);
int __stdcall Bematech_FI_VerificaAliquotasIss(char *flags);
int __stdcall Bematech_FI_VerificaCancelamentoCupom2HorasMFD(char *flag);
int __stdcall Bematech_FI_VerificaDepartamentos(char *departments);
int __stdcall Bematech_FI_VerificaEpromConectada(char *flag);
int __stdcall Bematech_FI_VerificaEstadoGaveta(short int *flag);
int __stdcall Bematech_FI_VerificaEstadoGavetaStr(char *flag);
int __stdcall Bematech_FI_VerificaEstadoImpressora(short int *ACK, short int *ST1, short int *ST2);
int __stdcall Bematech_FI_VerificaEstadoImpressoraStr(char *ACK, char *ST1, char *ST2);
int __stdcall Bematech_FI_VerificaEstadoImpressoraMFD(short int *ACK, short int *ST1, short int *ST2, short int *ST3);
int __stdcall Bematech_FI_VerificaEstadoImpressoraMFDStr(char *ACK, char *ST1, char *ST2, char *ST3);
int __stdcall Bematech_FI_VerificaFlagCorteMFD(short int *flag);
int __stdcall Bematech_FI_VerificaImpressoraLigada();
int __stdcall Bematech_FI_VerificaIndiceAliquotasIss(char *index);
int __stdcall Bematech_FI_VerificaModoOperacao(char *mode);
int __stdcall Bematech_FI_VerificaModoOperacaoCV0909(char *mode);
int __stdcall Bematech_FI_VerificaModoImpressora(char *mode);
int __stdcall Bematech_FI_VerificaReducaoZAutomatica(short int *flag);
int __stdcall Bematech_FI_VerificaSensorPoucoPapelMFD(char *flag);
int __stdcall Bematech_FI_VerificaStatusCheque(char *status);
int __stdcall Bematech_FI_VerificaStatusChequeStr(short int *status);
int __stdcall Bematech_FI_VerificaTotalizadoresParciais(char *totalizers);
int __stdcall Bematech_FI_VerificaTotalizadoresParciaisMFD(char *totalizers);
int __stdcall Bematech_FI_VerificaTotalizadoresParciaisCV0909(char *totalizers);
int __stdcall Bematech_FI_VerificaImpostoTotalizadoresParciaisCV0909(char *totalizers);
int __stdcall Bematech_FI_VerificaTruncamento(char *flag);
int __stdcall Bematech_FI_AlinhamentoCabecalhoProgramado(char *programedHeaderAlignment);
int __stdcall Bematech_FI_TimeoutRTDProgramado(char *programedRTDTimeout);
int __stdcall Bematech_FI_PrioridadeImpressoraProgramada(char *programedPrinterPriority);
int __stdcall Bematech_FI_RetornoPapelProgramado(char *programedPaperReturn);
int __stdcall Bematech_FI_ChaveCupomFiscalEletronico(char *searchMode, char *searchParameter, char *key);
/*int __stdcall Bematech_FI_RecuperaStatusSyncWak(bool *syncWak);
int __stdcall Bematech_FI_LimpaStatusSyncWak();*/

//FISCAL_PRINTER
int __stdcall Bematech_FI_AberturaDoDia(char *valueAux, char *paymentForm);
int __stdcall Bematech_FI_AbreComprovanteNaoFiscalVinculado(char *paymentForm, char *value, char *couponNumber);
int __stdcall Bematech_FI_AbreComprovanteNaoFiscalVinculadoCV0909(int paymentSequence, char *paymentFormIndex, int quantityOfPayments, int paymentNumber, char *CPF, char *name, char *address);
int __stdcall Bematech_FI_AbreComprovanteNaoFiscalVinculadoMFD(char *paymentForm, char *value, char *couponNumber, char *CPF, char *name, char *address);
int __stdcall Bematech_FI_AbreCupom(char *CPF);
int __stdcall Bematech_FI_AbreCupomCV0909(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_AbreCupomMFD(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_AbreRecebimentoNaoFiscalCV0909(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_AbreRecebimentoNaoFiscalMFD(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_AbreRelatorioGerencialCV0909(char *totalizer);
int __stdcall Bematech_FI_AbreRelatorioGerencialMFD(char *totalizer);
int __stdcall Bematech_FI_AbreSegundaViaNaoFiscalVinculadoMFD();
int __stdcall Bematech_FI_AcionaGaveta();
int __stdcall Bematech_FI_AcionaGuilhotinaCV0909();
int __stdcall Bematech_FI_AcionaGuilhotinaMFD(short int mode);
int __stdcall Bematech_FI_AcrescimoDescontoItemCV0909(char *item, char *incrementDiscount, char *incrementDiscountType, char *incrementDiscountValue);
int __stdcall Bematech_FI_AcrescimoDescontoItemMFD(char *item, char *incrementDiscount, char *incrementDiscountType, char *incrementDiscountValue);
int __stdcall Bematech_FI_AcrescimoDescontoSubtotalCV0909(char *flag, char *type, char *value);
int __stdcall Bematech_FI_AcrescimoDescontoSubtotalMFD(char *flag, char *type, char *value);
int __stdcall Bematech_FI_AcrescimoDescontoSubtotalRecebimentoMFD(char *flag, char *type, char *value);
int __stdcall Bematech_FI_AcrescimoItemNaoFiscalMFD(char *item, char *incrementDiscount, char *incrementDiscountType, char *incrementDiscountValue);
int __stdcall Bematech_FI_AlteraSimboloMoeda(char *currencySymbol);
int __stdcall Bematech_FI_AumentaDescricaoItem(char *description);
int __stdcall Bematech_FI_Autenticacao();
int __stdcall Bematech_FI_AutenticacaoMFD(char *lines, char *text);
int __stdcall Bematech_FI_CancelaAcrescimoDescontoItemCV0909(char *flag, char *item);
int __stdcall Bematech_FI_CancelaAcrescimoDescontoItemMFD(char *flag, char *item);
int __stdcall Bematech_FI_CancelaAcrescimoDescontoSubtotalCV0909(char *flag);
int __stdcall Bematech_FI_CancelaAcrescimoDescontoSubtotalMFD(char *flag);
int __stdcall Bematech_FI_CancelaAcrescimoDescontoSubtotalRecebimentoMFD(char *flag);
int __stdcall Bematech_FI_CancelaAcrescimoNaoFiscalMFD(char *item, char *incrementDiscount);
int __stdcall Bematech_FI_CancelaCupom();
int __stdcall Bematech_FI_CancelaCupomAtualCV0909();
int __stdcall Bematech_FI_CancelaCupomCV0909(char *COO);
int __stdcall Bematech_FI_CancelaCupomMFD(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_CancelaImpressaoCheque();
int __stdcall Bematech_FI_CancelaItemAnterior();
int __stdcall Bematech_FI_CancelaItemGenerico(char *item);
int __stdcall Bematech_FI_CancelaItemNaoFiscal(char *item);
int __stdcall Bematech_FI_CancelaItemNaoFiscalMFD(char *item);
int __stdcall Bematech_FI_CancelaItemParcial(char *item, char *quantity);
int __stdcall Bematech_FI_CancelaRecebimentoNaoFiscalMFD(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_CGC_IE(char *CGC, char *IE);
int __stdcall Bematech_FI_CupomAdicionalMFD();
int __stdcall Bematech_FI_DownloadMF(char *fileName);
int __stdcall Bematech_FI_DownloadMFCV0909(char *fileName, char *type, char *initialData, char *finalData);
int __stdcall Bematech_FI_DownloadMFD(char *fileName, char *downloadType, char *initialData, char *finalData, char *user);
int __stdcall Bematech_FI_DownloadMFDCV0909(char *fileName, char *downloadType, char *initialData, char *finalData);
int __stdcall Bematech_FI_DownloadSB(char *fileName);
int __stdcall Bematech_FI_DownloadSBCV0909(char *fileName);
int __stdcall Bematech_FI_DownloadTDM(char *fileName, char *type, char *initialData, char *finalData);
int __stdcall Bematech_FI_EfetuaFormaPagamento(char *paymentForm, char *value);
int __stdcall Bematech_FI_EfetuaFormaPagamentoDescricaoForma(char *paymentForm, char *value, char *description);
int __stdcall Bematech_FI_EfetuaFormaPagamentoIndice(char *paymentFormIndex, char *value);
int __stdcall Bematech_FI_EfetuaFormaPagamentoIndiceCV0909(char *paymentFormIndex, char *value, char *payments, char *description, char *paymentFormCode);
int __stdcall Bematech_FI_EfetuaFormaPagamentoIndiceDescricaoForma(char *paymentFormIndex, char *value, char *description);
int __stdcall Bematech_FI_EfetuaFormaPagamentoIndiceMFD(char *paymentFormIndex, char *value, char *payments, char *description);
int __stdcall Bematech_FI_EfetuaFormaPagamentoMFD(char *paymentForm, char *value, char *payments, char *description);
int __stdcall Bematech_FI_EfetuaRecebimentoNaoFiscalCV0909(char *totalizerIndex, char *value);
int __stdcall Bematech_FI_EfetuaRecebimentoNaoFiscalMFD(char *totalizerIndex, char *value);
int __stdcall Bematech_FI_EstornoFormasPagamento(char *originForm, char *destinyForm, char *value);
int __stdcall Bematech_FI_EstornoFormasPagamentoCV0909(char *originForm, char *destinyForm, char *value, int destinyPaymentSequence, char *message);
int __stdcall Bematech_FI_EstornoNaoFiscalVinculadoCV0909(char *CPF, char *name, char *address, char *COO);
int __stdcall Bematech_FI_EstornoNaoFiscalVinculadoMFD(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_EstornoNaoFiscalVinculadoPosteriorMFD(char *paymentForm, char *value, char *couponCOO, char *CDCCOO, char *CPF, char *name, char *address);
int __stdcall Bematech_FI_FechaComprovanteNaoFiscalVinculado();
int __stdcall Bematech_FI_FechaCupom(char *paymentForm, char *incrementsDiscount, char *incrementsDiscountType, char *incrementsDiscountValue, char *payedValue, char *message);
int __stdcall Bematech_FI_FechaCupomResumido(char *paymentForm, char *message);
int __stdcall Bematech_FI_FechamentoDoDia();
int __stdcall Bematech_FI_FechaRecebimentoNaoFiscalCV0909(char *message, int cutter);
int __stdcall Bematech_FI_FechaRecebimentoNaoFiscalMFD(char *message);
int __stdcall Bematech_FI_FechaRelatorioGerencial();
int __stdcall Bematech_FI_FechaRelatorioGerencialCV0909(int cutter);
int __stdcall Bematech_FI_FormatoDadosMF(char *MFDFile, char *destiny, char *format, char *readType, char *parameterType, char *initialData, char *finalData);
int __stdcall Bematech_FI_FormatoDadosMFD(char *MFDFile, char *destiny, char *format, char *downloadType, char *initialData, char *finalData, char *user);
int __stdcall Bematech_FI_ImpressaoFitaDetalhe(char *type, char *initialData, char *finalData, char *user);
int __stdcall Bematech_FI_ImpressaoFitaDetalheCV0909(char *type, char *initialData, char *finalData);
int __stdcall Bematech_FI_ImprimeClicheMFD();
int __stdcall Bematech_FI_ImprimeConfiguracoesImpressora();
int __stdcall Bematech_FI_ImprimeDepartamentos();
int __stdcall Bematech_FI_ImprimeRTDCV0909(char *message);
int __stdcall Bematech_FI_IniciaFechamentoCupom(char *incrementDiscount, char *incrementDiscountType, char *incrementDiscountValue);
int __stdcall Bematech_FI_IniciaFechamentoCupomMFD(char *incrementDiscount, char *incrementDiscountType, char *incrementValue, char *discountValue);
int __stdcall Bematech_FI_IniciaFechamentoRecebimentoNaoFiscalMFD(char *incrementDiscount, char *incrementDiscountType, char *incrementValue, char *discountValue);
int __stdcall Bematech_FI_InterrompeLeiturasCV0909(void);
int __stdcall Bematech_FI_LeituraMemoriaFiscalData(char *initialDate, char *finalDate);
int __stdcall Bematech_FI_LeituraMemoriaFiscalDataCV0909(char *initialDate, char *finalDate, char *readFlag);
int __stdcall Bematech_FI_LeituraMemoriaFiscalDataMFD(char *initialDate, char *finalDate, char *readFlag);
int __stdcall Bematech_FI_LeituraMemoriaFiscalReducao(char *initialReduction, char *finalReduction);
int __stdcall Bematech_FI_LeituraMemoriaFiscalReducaoCV0909(char *initialReduction, char *finalReduction, char *readFlag);
int __stdcall Bematech_FI_LeituraMemoriaFiscalReducaoMFD(char *initialReduction, char *finalReduction, char *readFlag);
int __stdcall Bematech_FI_LeituraMemoriaFiscalSerialData(char *initialDate, char *finalDate);
int __stdcall Bematech_FI_LeituraMemoriaFiscalSerialDataCV0909(char *initialDate, char *finalDate, char *readFlag);
int __stdcall Bematech_FI_LeituraMemoriaFiscalSerialDataMFD(char *initialDate, char *finalDate, char *readFlag);
int __stdcall Bematech_FI_LeituraMemoriaFiscalSerialReducao(char *initialReduction, char *finalReduction);
int __stdcall Bematech_FI_LeituraMemoriaFiscalSerialReducaoCV0909(char *initialReduction, char *finalReduction, char *readFlag);
int __stdcall Bematech_FI_LeituraMemoriaFiscalSerialReducaoMFD(char *initialReduction, char *finalReduction, char *readFlag);
int __stdcall Bematech_FI_LeituraX(void);
int __stdcall Bematech_FI_LeituraXSerial(void);
int __stdcall Bematech_FI_MapaResumo(void);
int __stdcall Bematech_FI_MapaResumoMFD(void);
int __stdcall Bematech_FI_RecebimentoNaoFiscal(char *totalizerIndex, char *receivingValue, char *paymentForm);
int __stdcall Bematech_FI_ReducaoZ(char *date, char *hour);
int __stdcall Bematech_FI_ReducaoZCV0909(char *date, char *hour, int transmit);
int __stdcall Bematech_FI_ReimpressaoNaoFiscalVinculadoCV0909();
int __stdcall Bematech_FI_ReimpressaoNaoFiscalVinculadoMFD();
int __stdcall Bematech_FI_RelatorioGerencial(char *text);
int __stdcall Bematech_FI_ResetaImpressora();
int __stdcall Bematech_FI_BufferRespostaCV0909(char *buffer);
int __stdcall Bematech_FI_RetornaFatMFD(void);
int __stdcall Bematech_FI_Sangria(char *value);
int __stdcall Bematech_FI_SangriaCV0909(char *value, char *information);
int __stdcall Bematech_FI_SegundaViaNaoFiscalVinculadoCV0909();
int __stdcall Bematech_FI_SegundaViaNaoFiscalVinculadoMFD();
int __stdcall Bematech_FI_SetaMFD(int flagMFD);
int __stdcall Bematech_FI_SubTotalizaCupomMFD();
int __stdcall Bematech_FI_SubTotalizaRecebimentoMFD();
int __stdcall Bematech_FI_Suprimento(char *value, char *paymentForm);
int __stdcall Bematech_FI_SuprimentoCV0909(char *value, char *information);
int __stdcall Bematech_FI_TerminaFechamentoCupom(char *message);
int __stdcall Bematech_FI_TerminaFechamentoCupomCodigoBarrasMFD(const char *tmpMessage, const char *codeType, const char *code, int height, int tmpWidth, int characterPosition, int source, int margin, int fixErrors, int columns);
int __stdcall Bematech_FI_TerminaFechamentoCupomCV0909(char *information, int additionalCoupon, int cutter);
int __stdcall Bematech_FI_TotalizaCupomMFD();
int __stdcall Bematech_FI_TotalizaRecebimentoMFD();
int __stdcall Bematech_FI_UsaComprovanteNaoFiscalVinculado(char *text);
int __stdcall Bematech_FI_UsaRelatorioGerencialCV0909(char *text);
int __stdcall Bematech_FI_UsaRelatorioGerencialMFD(char *text);
int __stdcall Bematech_FI_UsaUnidadeMedida(char *unitOfMeasure);
int __stdcall Bematech_FI_VendeItem(char *code, char *description, char *tax, char *quantityType, char *quantity, short int decimal, char *unitary, char *discountType, char *discount);
int __stdcall Bematech_FI_VendeItemArredondamentoMFD(char *code, char *description, char *tax, char *unitOfMeasure, char *quantityFractionated, char *unitary, char *incrementValue, char *discountValue, bool rounds);
int __stdcall Bematech_FI_VendeItemCV0909(char *code, char *description, char *tax, char *quantity, short decimal, char *unitaryValue, char *unitOfMeasure, char *decimalsUnitaryValue, char *typeOfCalculation);
int __stdcall Bematech_FI_VendeItemDetalhadoCV0909(char *code, char *description, char *tax, char *unitOfMeasure, char *quantity, char *decimalsQuantity, char *unitaryValue, char *decimalUnitaryValue, char *typeOfCalculation, char *EAN13, char *NCM,char *CFOP, char *additionalInformation, char *productOrigin, char *CST_ICMS, char *CSOSN, char *IBGECode, char *itemServiceList, char *ISSCode, char *ISSOperationNature, char *ISSIncentiveIndicator);
int __stdcall Bematech_FI_VendeItemDepartamento(char *code, char *description, char *tax, char *unitValue, char *quantity, char *incrementValue, char *discountValue, char *indexDepartment, char *unitOfMeasure);

//NFCe
int __stdcall Bematech_FI_TerminaFechamentoCupomNFCe(char *message, char *taxes);
int __stdcall Bematech_FI_DadosConsumidorNFCe(char *CPF, char *name, char *address, char *complement, char *number, char *neighborhood, char *IBGECode, char *city, char *UF, char *CEP, char *countyCode, char *country, char *phone, char *stateRegistrationIndicator, char *stateRegistration, char *SUFRAMACode, char *email);
int __stdcall Bematech_FI_ChaveAcessoNFCe(char *index, char *counter, char *accessKey);
int __stdcall Bematech_FI_UltimaChaveAcessoNFCe(char *accessKey);
int __stdcall Bematech_FI_StatusUltimaNFCe(char *status);
int __stdcall Bematech_FI_RetornaInformacoesNFCe(char* type, char *value, char* accessKey, char* serie, char* NFCeNumber, char* cancelled, char* sendStatus, char* sendProtocol, char* sendProtocolDatetime, char* cancellationStatus, char* cancellationProtocol);
int __stdcall Bematech_FI_StatusUltimoCancelamentoNFCe(char *status);
int __stdcall Bematech_FI_ProgramaContadorNFCe(char *index, char *counter);
int __stdcall Bematech_FI_NumeroSerieNFCe(char *serialNumber);
int __stdcall Bematech_FI_NumeroNotaNFCe(char *noteNumber);
int __stdcall Bematech_FI_DadosEnvioNFCe(char *layoutType, char *sendType, char *email);
int __stdcall Bematech_FI_EfetuaFormaPagamentoNFCe(char *paymentForm, char *value, char *licensingCNPJ, char *licensingCode, char *authorizationCode);
int __stdcall Bematech_FI_EfetuaFormaPagamentoNFCeEx(char *paymentForm, char *value, char *licensingCNPJ, char *licensingCode, char *authorizationCode, char *integrationCode);
int __stdcall Bematech_FI_ProtocoloUltimaNFCe(char *protocol, char *dateHour);
int __stdcall Bematech_FI_TextoLivreDANFENFCe(char *message);
int __stdcall Bematech_FI_AdicionaInformacoesCombustivel(char *itemIndex, char *ANPProductCode, char *percentMixGN, char *CODIF, char *quantity, char *consumeUF, char *BCProductCIDE, char *taxProductCIDE, char *valueCIDE, char *fuelNozzleNumber, char *fuelPumpNumber, char *fuelTankNumber, char *fuelGaugeInitial, char *fuelGaugeFinal);

//SAT
int __stdcall Bematech_FI_UltimasInformacoesSAT(char *accessKey, char *billNumber, char *satNumber);
int __stdcall Bematech_FI_RetornaMensagemSefazSAT(char *message, char *code, char *errorMessage, char *errorCode);
int __stdcall Bematech_FI_DadosEntregaSAT(char *address, char *number, char *complement, char *neighborhood, char *city, char *UF);
int __stdcall Bematech_FI_DadosSoftwareHouseSAT(char *CNPJ, char *softwareSignature);
int __stdcall Bematech_FI_HabilitaDesabilitaExtratoExtendidoSAT(char *extendedOutput);
int __stdcall Bematech_FI_InsereCampoUsoLivretFiscoSAT(char *itemIndex, char *identification, char *content);
int __stdcall Bematech_FI_RetornaInformacoesCancelamentoSAT(char *chaveAcessoCFe, char *chaveAcessoCancelamento, char *dataHoraProcessamento, char *codigoSefaz, char *mensagemSefaz);

//FISCAL_SOLUTION
int __stdcall Bematech_FI_VendeItemCompleto(char *code, char *EAN13, char *description, char *indexDepartment, char *tax, char *unitOfMeasure, char *quantityType, char *decimalsQuantity, char *quantity, char *decimalsUnitaryValue, char *unitaryValue, char *increaseDiscountType, char *incrementValue, char *discountValue, char *typeOfCalculation, char *NCM, char *CFOP, char *additionalInformation, char *CST_ICMS, char *productOrigin, char *itemServiceList, char *ISSCode, char *ISSOperationNature, char *ISSIncentiveIndicator, char *IBGECode, char *CSOSN, char *basisCalculuationValueRetained, char *ICMSValueRetained, char *basisCalculationMode, char *basisCalculationReductionPercentual, char *ICMSSTBasisCalculationMode, char *ICMSSTValueAddedMarginPercentual, char *ICMSSTBasisCalculationReductionPercentual, char *ICMSSTBasisCalculationReductionValue, char *ICMSSTTax, char *ICMSSTValue, char *ICMSUnencumberedValue, char *ICMSUnburdeningMotive, char *creditCalculationApplicableTax, char *ICMSSNCreditValue, char *incidentTaxTotalValue, char *pisCst, char *pisBasisCalculation, char *pisTax, char *pisValue, char *pisQuantitySell, char *pisTaxValueProd, char *cofinsCst, char *cofinsBasisCalculation, char *cofinsTax, char *cofinsValue, char *cofinsQuantitySell, char *cofinsTaxValueProd, char *CEST, char *TIPI, char *reserved01, char *reserved02, char *reserved03, char *reserved04, char *reserved05, char *reserved06, char *reserved07, char *reserved08);
int __stdcall Bematech_FI_VendeItemCompletoJSON(char *parameter);

//FISCAL_PROGRAMATION
int __stdcall Bematech_FI_AtivaDesativaAlinhamentoEsquerdaMFD(short int flag);
int __stdcall Bematech_FI_AtivaDesativaCancelamentoCupom2HorasMFD(int flag);
int __stdcall Bematech_FI_AtivaDesativaCorteProximoMFD(void);
int __stdcall Bematech_FI_AtivaDesativaCorteTotalMFD(short int flag);
int __stdcall Bematech_FI_AtivaDesativaGuilhotinaMFD(short int flag);
int __stdcall Bematech_FI_AtivaDesativaSensorPoucoPapelMFD(int flag);
int __stdcall Bematech_FI_AtivaDesativaTratamentoONOFFLineMFD(short int flag);
int __stdcall Bematech_FI_AtivaDesativaVendaUmaLinhaMFD(short int flag);
int __stdcall Bematech_FI_AvancaPapelAcionaGuilhotinaMFD(short int lines, short int mode);
int __stdcall Bematech_FI_ConfiguraCorteGuilhotinaMFD(int time);
int __stdcall Bematech_FI_EspacoEntreLinhas(int dots);
int __stdcall Bematech_FI_ForcaImpactoAgulhas(short int impactValue);
int __stdcall Bematech_FI_LinhasEntreCupons(int lines);
int __stdcall Bematech_FI_NomeiaDepartamento(int index, char *department);
int __stdcall Bematech_FI_NomeiaRelatorioGerencialCV0909(char *index, char *description);
int __stdcall Bematech_FI_NomeiaRelatorioGerencialMFD(char *index, char *description);
int __stdcall Bematech_FI_NomeiaTotalizadorNaoSujeitoIcms(int index, char *totalizer);
int __stdcall Bematech_FI_NomeiaTotalizadorNaoSujeitoIcmsCV0909(int index, char *totalizer, char *inOrOut);
int __stdcall Bematech_FI_ProgramaAliquota(char *taxAmount, int typeofAmount);
int __stdcall Bematech_FI_ProgramaAliquotaCV0909(char *taxAmount, int typeofAmount, char *taxIndex);
int __stdcall Bematech_FI_ProgramaAliquotasEspeciais(char *taxF, char *taxI, char *taxN, char *taxFS, char *taxIS, char *taxNS);
int __stdcall Bematech_FI_ProgramaArredondamento(void);
int __stdcall Bematech_FI_ProgramaCaracterAutenticacao(char *parameters);
int __stdcall Bematech_FI_ProgramaFormaPagamentoCV0909(char *paymentIndex, char *paymentForm, int linkedCCD);
int __stdcall Bematech_FI_ProgramaFormaPagamentoMFD(char *paymentForm, char *operationTef);
int __stdcall Bematech_FI_ProgramaHorarioVerao(void);
int __stdcall Bematech_FI_ProgramaHorarioVeraoCV0909(int mode);
int __stdcall Bematech_FI_ProgramaIdAplicativoCV0909(char *idApp);
int __stdcall Bematech_FI_ProgramaIdAplicativoMFD(char *idApp);
int __stdcall Bematech_FI_ProgramaIdentificacaoConsumidor(char *CPF, char *name, char *address);
int __stdcall Bematech_FI_ProgramaLoja(char *storeNumber);
int __stdcall Bematech_FI_ProgramaMoedaPlural(char *pluralCurrency);
int __stdcall Bematech_FI_ProgramaMoedaSingular(char *singularCurrency);
int __stdcall Bematech_FI_ProgramaOperador(char *data);
int __stdcall Bematech_FI_ProgramaQuantidadeDocumentosAutorizados(char *data);
int __stdcall Bematech_FI_ProgramaTruncamento(void);

//FISCAL_UTILS
void __stdcall Bematech_FI_CriptografaDescriptografa(char *buffer, unsigned int sizeBuffer, char *key, unsigned int sizeKey);
int __stdcall Bematech_FI_SelecionaXMLLocal();
int __stdcall Bematech_FI_SelecionaIniLocal();
int __stdcall Bematech_FI_HabilitaDesabilitaRetornoEstendidoMFD(char *extendedFlag);
int __stdcall Bematech_FI_HabilitaDesabilitaAssinaturaDigital(int status);

//REGION_PAF
int __stdcall Bematech_FI_GrandeTotalCriptografado(char *totalGrid);
int __stdcall Bematech_FI_AbreDocumentoAuxiliarVenda(char *index, char *title, char *DAVNumber, char *issuerName, char *issuerCNPJCPF, char *recipientName, char *recipientCNPJCPF);
int __stdcall Bematech_FI_AbreRelatorioMeiosPagamento(char *index);
int __stdcall Bematech_FI_ArquivoMFD(char *fileName, char *initialData, char *finalData, char *downloadType, char *user, int parameter, char *publicKey, char *privateKey, int singleFile);
int __stdcall Bematech_FI_ArquivoMFDPath(char *fileName, char *destinyFileName, char *initialData, char *finalData, char *downloadType, char *user, int parameter, char *publicKey, char *privateKey, int singleFile);
int __stdcall Bematech_FI_DAVEmitidosArquivo(char *fileName, char *initialDate, char *finalDate, char *publicKey, char *privateKey);
int __stdcall Bematech_FI_DAVEmitidosRelatorioGerencial(char *index, char *initialDate, char *finalDate);
int __stdcall Bematech_FI_EspelhoMFD(char *destinyFileName, char *initialData, char *finalData, char *downloadType, char *user, char *publicKey, char *privateKey);
int __stdcall Bematech_FI_FechaDocumentoAuxiliarVenda(char *total);
int __stdcall Bematech_FI_FechaRelatorioMeiosPagamento();
int __stdcall Bematech_FI_GeraRegistrosTipoE(char * szMemFileName, char * szReportFileName, char * szDataInicial, 
                                             char * szDataFinal, char * szRazaoSocial, char * szEndereco, char * szModelo, char * szCmd, 
                                             char * szCRZ, char * szCRO, char * szCOO, char * szGNF, char * szCCF, 
                                             char * szCVC, char * szCBP, char * szGRG, char * szCMV, char * szCFD, 
                                             char * szGT, char * szNECF, char * szBP);
int __stdcall Bematech_FI_GeraRegistrosTipoECV0909(char *strMfdTdmFileName, char *strMfFileName, 
                                                   char *strReportFileName, char *strDataInicial, char *strDataFinal, 
                                                   char *strCmd, char *printerKey);
int __stdcall Bematech_FI_GrandeTotalDescriptografado(char *encryptedTotalGrid, char *decryptTotalGrid);
int __stdcall Bematech_FI_IdentificacaoPAFECF(char *index, char *reportNumber, char *developerCNPJ, char *companyName, char *address, char *phone, char *contact, char *tradeName, char *version, char *mainExecutable, char *mainExecutableMD5, char *otherFiles, char *otherFilesMD5, char *registrationNumber);
int __stdcall Bematech_FI_LeituraMemoriaFiscalSerialDataPAFECF(char *initialDate, char *finalDate, char *readFlag, char *publicKey, char *privateKey);
int __stdcall Bematech_FI_LeituraMemoriaFiscalSerialReducaoPAFECF(char *initialReduction, char *finalReduction, char *readFlag, char *publicKey, char *privateKey);
int __stdcall Bematech_FI_NomeiaRelatorios(char *name);
int __stdcall Bematech_FI_NomeiaRelatorioDAVEmitidos();
int __stdcall Bematech_FI_NomeiaRelatorioDocumentoAuxiliarDeVenda();
int __stdcall Bematech_FI_NomeiaRelatorioIdentificacaoPAFECF();
int __stdcall Bematech_FI_NomeiaRelatorioMeiosDePagamento();
int __stdcall Bematech_FI_NomeiaRelatoriosPAFECF();
int __stdcall Bematech_FI_TerminaFechamentoCupomPreVenda(char *MD5, char *preSaleNumber, char *promotionalMessage);
int __stdcall Bematech_FI_UsaDocumentoAuxiliarVenda(char *item, char *unitValue, char *totalValue);
int __stdcall Bematech_FI_UsaRelatorioMeiosPagamento(char *identification, char *documentType, char *accumulatedValue, char *date);
int __stdcall Bematech_FI_ConcatenaArquivos1704(char *fileFolder, char *destinyFolder, char *serialNumber);

//REGION_CAT52
int __stdcall Bematech_FI_GeraRegistrosCAT52MFD(char *MFDFile, char *date);
int __stdcall Bematech_FI_GeraRegistrosCAT52MFDEx(char *source, char *date, char *destiny);
void __stdcall Bematech_FI_AlteraParametrizacaoRegistrosTipoE(int parametrization);

//REGION SPED
int __stdcall Bematech_FI_GeraRegistrosSpedMFD(char *source, char *destiny, char *initialDate, char *finalDate, char *perfil, char *CFOP, char *codObsReleaseFiscal, char *taxPis, char *taxCofins);
int __stdcall Bematech_FI_GeraRegistrosSpedCompleto(char *source, char *destiny, char *initialDate, char *finalDate, char *perfil, char *CFOP, char *codObsReleaseFiscal, char *taxPis, char *taxCofins, char *companyName, char *cityCodeIBGE);

//REGION_COMMUNICATION
bool __stdcall Bematech_FI_AbrePorta(int *port);
int __stdcall Bematech_FI_AbrePortaSerial();
int __stdcall Bematech_FI_FechaPortaSerial();

//REGION_CRYPTO
int __stdcall Bematech_FI_ValidaAssinaturaDigital(char *filename, char *module, char *exponent);

//REGION_TICKET
int __stdcall Bematech_FI_AbreBilhetePassagem(char *endValuePrint, char *emphasizedPrint, char *boarding, char *destiny, char *line, char *prefix, char *agent, char *agency, char *date, char *hour, char *seat, char *platform);
int __stdcall Bematech_FI_AbreBilhetePassagemMFD(char *boarding, char *destiny, char *line, char *agency, char *date, char *hour, char *seat, char *platform, char *type, char *RG, char *name, char *address, char *UF);
int __stdcall Bematech_FI_ContadorBilhetePassagem(char *counterShuttle);

//REGION_BANK
int __stdcall Bematech_FI_ImprimeCheque(char *bankNumber, char *value, char *favored, char *city, char *date, char *msg);
int __stdcall Bematech_FI_ImprimeChequeMFD(char *bankNumber, char *value, char *favored, char *city, char *date, char *msg, char *versePrint, char *lines);
int __stdcall Bematech_FI_ImprimeChequeMFDEx(char *bankNumber, char *value, char *favored, char *city, char *date, char *msg, char *source);
int __stdcall Bematech_FI_ImprimeCopiaCheque();
int __stdcall Bematech_FI_ImprimeInformacaoChequeMFD(int position, int lines, char *msg);
int __stdcall Bematech_FI_IncluiCidadeFavorecido(char *city, char *favored);
int __stdcall Bematech_FI_LeituraChequeMFD(char *CMC7);
int __stdcall Bematech_FI_ViraChequeMFD();

//REGION_BARCODE
int __stdcall Bematech_FI_CodigoBarrasCODABARMFD(char *code);
int __stdcall Bematech_FI_CodigoBarrasCODE128MFD(char *code);
int __stdcall Bematech_FI_CodigoBarrasCODE39MFD(char *code);
int __stdcall Bematech_FI_CodigoBarrasCODE93MFD(char *code);
int __stdcall Bematech_FI_CodigoBarrasEAN13MFD(char *code);
int __stdcall Bematech_FI_CodigoBarrasEAN8MFD(char *code);
int __stdcall Bematech_FI_CodigoBarrasISBNMFD(char *code);
int __stdcall Bematech_FI_CodigoBarrasITFMFD(char *code);
int __stdcall Bematech_FI_CodigoBarrasMSIMFD(char *code);
int __stdcall Bematech_FI_CodigoBarrasPDF417MFD(int correctionError, int height, int width, int colummns, char *code);
int __stdcall Bematech_FI_CodigoBarrasPLESSEYMFD(char *code);
int __stdcall Bematech_FI_CodigoBarrasUPCAMFD(char *code);
int __stdcall Bematech_FI_CodigoBarrasUPCEMFD(char *code);
int __stdcall Bematech_FI_ConfiguraCodigoBarrasMFD(int heigth, int width, int positionCharacter, int source, int margin);
int __stdcall Bematech_FI_CodigoBarrasQRCode(int correctionError, int moduleSize, int codeType, int QRCodeVersion, int encodingModes, char * code);

//REGION_SINTEGRA
int __stdcall Bematech_FI_DadosSintegra(char *initialDate, char *finalDate);
int __stdcall Bematech_FI_DadosSintegraMFD(char *initialDate, char *finalDate);
int __stdcall Bematech_FI_GeraRelatorioSintegraMFD(int report, char *origin, char *destiny, char *month, char *year, char *corporateName, char *address, char *number, char *complement, char *neighborhood, char *city, char *CEP, char *phone, char *fax, char *contact);
int __stdcall Bematech_FI_RegistrosTipo60();
int __stdcall Bematech_FI_RelatorioSintegraMFD(int report, char *file, char *month, char *year, char *corporateName, char *address, char *number, char *complement, char *neighborhood, char *city, char *CEP, char *phone, char *fax, char *contact);
int __stdcall Bematech_FI_RelatorioTipo60Analitico();
int __stdcall Bematech_FI_RelatorioTipo60AnaliticoMFD();
int __stdcall Bematech_FI_RelatorioTipo60Mestre();

//REGION_TEF
int __stdcall Bematech_FI_IniciaModoTEF();
int __stdcall Bematech_FI_UsaComprovanteNaoFiscalVinculadoTEF(char *text);
int __stdcall Bematech_FI_FinalizaModoTEF();

#ifdef BEMAFI_FABRICA
//REGION_FACTORY
int __stdcall Bematech_FI_ProgramaDataHoraImpressora(char *date, char *hour, char *dayLightSavings);
int __stdcall Bematech_FI_NumeroSerialCriptochip(char *serialNumber);
#endif //BEMAFI_FABRICA

#if __cplusplus
	}
#endif

#endif // !defined(EA_D7EC8BD3_F3BA_4c22_B76D_CB11BBBF52A0__INCLUDED_)
